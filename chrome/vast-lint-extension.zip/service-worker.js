// src/background/service-worker.ts
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== "UPDATE_BADGE") return;
  const tabId = sender.tab?.id;
  if (tabId == null) return;
  const incoming = msg.vasts;
  if (!incoming?.length) return;
  const key = `tab_${tabId}`;
  chrome.storage.session.get(key).then((stored) => {
    const prev = stored[key] ?? { errors: 0, warnings: 0, infos: 0, vasts: [] };
    const next = {
      errors: prev.errors + incoming.reduce((s, v) => s + v.errors, 0),
      warnings: prev.warnings + incoming.reduce((s, v) => s + v.warnings, 0),
      infos: prev.infos + incoming.reduce((s, v) => s + v.infos, 0),
      vasts: [...prev.vasts, ...incoming]
    };
    chrome.storage.session.set({ [key]: next });
    setBadge(tabId, next.errors, next.warnings);
  });
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    chrome.storage.session.remove(`tab_${tabId}`);
    chrome.action.setBadgeText({ text: "", tabId });
  }
});
function setBadge(tabId, errors, warnings) {
  if (errors > 0) {
    chrome.action.setBadgeText({ text: String(errors), tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#e53935", tabId });
  } else if (warnings > 0) {
    chrome.action.setBadgeText({ text: String(warnings), tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#f4a000", tabId });
  } else {
    chrome.action.setBadgeText({ text: "\u2713", tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#43a047", tabId });
  }
}
