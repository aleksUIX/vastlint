"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../npm/vastlint_wasm_bg.js
  var vastlint_wasm_bg_exports = {};
  __export(vastlint_wasm_bg_exports, {
    __wbg_Error_2e59b1b37a9a34c3: () => __wbg_Error_2e59b1b37a9a34c3,
    __wbg_Number_e6ffdb596c888833: () => __wbg_Number_e6ffdb596c888833,
    __wbg_String_8564e559799eccda: () => __wbg_String_8564e559799eccda,
    __wbg___wbindgen_boolean_get_a86c216575a75c30: () => __wbg___wbindgen_boolean_get_a86c216575a75c30,
    __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57: () => __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57,
    __wbg___wbindgen_in_4bd7a57e54337366: () => __wbg___wbindgen_in_4bd7a57e54337366,
    __wbg___wbindgen_is_function_49868bde5eb1e745: () => __wbg___wbindgen_is_function_49868bde5eb1e745,
    __wbg___wbindgen_is_null_344c8750a8525473: () => __wbg___wbindgen_is_null_344c8750a8525473,
    __wbg___wbindgen_is_object_40c5a80572e8f9d3: () => __wbg___wbindgen_is_object_40c5a80572e8f9d3,
    __wbg___wbindgen_is_undefined_c0cca72b82b86f4d: () => __wbg___wbindgen_is_undefined_c0cca72b82b86f4d,
    __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944: () => __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944,
    __wbg___wbindgen_number_get_7579aab02a8a620c: () => __wbg___wbindgen_number_get_7579aab02a8a620c,
    __wbg___wbindgen_string_get_914df97fcfa788f2: () => __wbg___wbindgen_string_get_914df97fcfa788f2,
    __wbg___wbindgen_throw_81fc77679af83bc6: () => __wbg___wbindgen_throw_81fc77679af83bc6,
    __wbg_call_7f2987183bb62793: () => __wbg_call_7f2987183bb62793,
    __wbg_done_547d467e97529006: () => __wbg_done_547d467e97529006,
    __wbg_entries_616b1a459b85be0b: () => __wbg_entries_616b1a459b85be0b,
    __wbg_from_741da0f916ab74aa: () => __wbg_from_741da0f916ab74aa,
    __wbg_get_4848e350b40afc16: () => __wbg_get_4848e350b40afc16,
    __wbg_get_ed0642c4b9d31ddf: () => __wbg_get_ed0642c4b9d31ddf,
    __wbg_get_f96702c6245e4ef9: () => __wbg_get_f96702c6245e4ef9,
    __wbg_get_unchecked_7d7babe32e9e6a54: () => __wbg_get_unchecked_7d7babe32e9e6a54,
    __wbg_get_with_ref_key_6412cf3094599694: () => __wbg_get_with_ref_key_6412cf3094599694,
    __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a: () => __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a,
    __wbg_instanceof_Uint8Array_4b8da683deb25d72: () => __wbg_instanceof_Uint8Array_4b8da683deb25d72,
    __wbg_isSafeInteger_ea83862ba994770c: () => __wbg_isSafeInteger_ea83862ba994770c,
    __wbg_iterator_de403ef31815a3e6: () => __wbg_iterator_de403ef31815a3e6,
    __wbg_length_0c32cb8543c8e4c8: () => __wbg_length_0c32cb8543c8e4c8,
    __wbg_length_6e821edde497a532: () => __wbg_length_6e821edde497a532,
    __wbg_new_4f9fafbb3909af72: () => __wbg_new_4f9fafbb3909af72,
    __wbg_new_a560378ea1240b14: () => __wbg_new_a560378ea1240b14,
    __wbg_new_f3c9df4f38f3f798: () => __wbg_new_f3c9df4f38f3f798,
    __wbg_next_01132ed6134b8ef5: () => __wbg_next_01132ed6134b8ef5,
    __wbg_next_b3713ec761a9dbfd: () => __wbg_next_b3713ec761a9dbfd,
    __wbg_prototypesetcall_3e05eb9545565046: () => __wbg_prototypesetcall_3e05eb9545565046,
    __wbg_set_6be42768c690e380: () => __wbg_set_6be42768c690e380,
    __wbg_set_6c60b2e8ad0e9383: () => __wbg_set_6c60b2e8ad0e9383,
    __wbg_set_8ee2d34facb8466e: () => __wbg_set_8ee2d34facb8466e,
    __wbg_set_wasm: () => __wbg_set_wasm,
    __wbg_value_7f6052747ccf940f: () => __wbg_value_7f6052747ccf940f,
    __wbindgen_cast_0000000000000001: () => __wbindgen_cast_0000000000000001,
    __wbindgen_cast_0000000000000002: () => __wbindgen_cast_0000000000000002,
    __wbindgen_cast_0000000000000003: () => __wbindgen_cast_0000000000000003,
    __wbindgen_init_externref_table: () => __wbindgen_init_externref_table,
    fix: () => fix,
    fixWithOptions: () => fixWithOptions,
    rules: () => rules,
    validate: () => validate,
    validateWithOptions: () => validateWithOptions
  });
  function fix(xml) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.fix(ptr0, len0);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function fixWithOptions(xml, options) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.fixWithOptions(ptr0, len0, options);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function rules() {
    const ret = wasm.rules();
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function validate(xml) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validate(ptr0, len0);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function validateWithOptions(xml, options) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWithOptions(ptr0, len0, options);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function __wbg_Error_2e59b1b37a9a34c3(arg0, arg1) {
    const ret = Error(getStringFromWasm0(arg0, arg1));
    return ret;
  }
  function __wbg_Number_e6ffdb596c888833(arg0) {
    const ret = Number(arg0);
    return ret;
  }
  function __wbg_String_8564e559799eccda(arg0, arg1) {
    const ret = String(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  }
  function __wbg___wbindgen_boolean_get_a86c216575a75c30(arg0) {
    const v = arg0;
    const ret = typeof v === "boolean" ? v : void 0;
    return isLikeNone(ret) ? 16777215 : ret ? 1 : 0;
  }
  function __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57(arg0, arg1) {
    const ret = debugString(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  }
  function __wbg___wbindgen_in_4bd7a57e54337366(arg0, arg1) {
    const ret = arg0 in arg1;
    return ret;
  }
  function __wbg___wbindgen_is_function_49868bde5eb1e745(arg0) {
    const ret = typeof arg0 === "function";
    return ret;
  }
  function __wbg___wbindgen_is_null_344c8750a8525473(arg0) {
    const ret = arg0 === null;
    return ret;
  }
  function __wbg___wbindgen_is_object_40c5a80572e8f9d3(arg0) {
    const val = arg0;
    const ret = typeof val === "object" && val !== null;
    return ret;
  }
  function __wbg___wbindgen_is_undefined_c0cca72b82b86f4d(arg0) {
    const ret = arg0 === void 0;
    return ret;
  }
  function __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944(arg0, arg1) {
    const ret = arg0 == arg1;
    return ret;
  }
  function __wbg___wbindgen_number_get_7579aab02a8a620c(arg0, arg1) {
    const obj = arg1;
    const ret = typeof obj === "number" ? obj : void 0;
    getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
  }
  function __wbg___wbindgen_string_get_914df97fcfa788f2(arg0, arg1) {
    const obj = arg1;
    const ret = typeof obj === "string" ? obj : void 0;
    var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  }
  function __wbg___wbindgen_throw_81fc77679af83bc6(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
  }
  function __wbg_call_7f2987183bb62793() {
    return handleError(function(arg0, arg1) {
      const ret = arg0.call(arg1);
      return ret;
    }, arguments);
  }
  function __wbg_done_547d467e97529006(arg0) {
    const ret = arg0.done;
    return ret;
  }
  function __wbg_entries_616b1a459b85be0b(arg0) {
    const ret = Object.entries(arg0);
    return ret;
  }
  function __wbg_from_741da0f916ab74aa(arg0) {
    const ret = Array.from(arg0);
    return ret;
  }
  function __wbg_get_4848e350b40afc16(arg0, arg1) {
    const ret = arg0[arg1 >>> 0];
    return ret;
  }
  function __wbg_get_ed0642c4b9d31ddf() {
    return handleError(function(arg0, arg1) {
      const ret = Reflect.get(arg0, arg1);
      return ret;
    }, arguments);
  }
  function __wbg_get_f96702c6245e4ef9() {
    return handleError(function(arg0, arg1) {
      const ret = Reflect.get(arg0, arg1);
      return ret;
    }, arguments);
  }
  function __wbg_get_unchecked_7d7babe32e9e6a54(arg0, arg1) {
    const ret = arg0[arg1 >>> 0];
    return ret;
  }
  function __wbg_get_with_ref_key_6412cf3094599694(arg0, arg1) {
    const ret = arg0[arg1];
    return ret;
  }
  function __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a(arg0) {
    let result;
    try {
      result = arg0 instanceof ArrayBuffer;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  }
  function __wbg_instanceof_Uint8Array_4b8da683deb25d72(arg0) {
    let result;
    try {
      result = arg0 instanceof Uint8Array;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  }
  function __wbg_isSafeInteger_ea83862ba994770c(arg0) {
    const ret = Number.isSafeInteger(arg0);
    return ret;
  }
  function __wbg_iterator_de403ef31815a3e6() {
    const ret = Symbol.iterator;
    return ret;
  }
  function __wbg_length_0c32cb8543c8e4c8(arg0) {
    const ret = arg0.length;
    return ret;
  }
  function __wbg_length_6e821edde497a532(arg0) {
    const ret = arg0.length;
    return ret;
  }
  function __wbg_new_4f9fafbb3909af72() {
    const ret = new Object();
    return ret;
  }
  function __wbg_new_a560378ea1240b14(arg0) {
    const ret = new Uint8Array(arg0);
    return ret;
  }
  function __wbg_new_f3c9df4f38f3f798() {
    const ret = new Array();
    return ret;
  }
  function __wbg_next_01132ed6134b8ef5(arg0) {
    const ret = arg0.next;
    return ret;
  }
  function __wbg_next_b3713ec761a9dbfd() {
    return handleError(function(arg0) {
      const ret = arg0.next();
      return ret;
    }, arguments);
  }
  function __wbg_prototypesetcall_3e05eb9545565046(arg0, arg1, arg2) {
    Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
  }
  function __wbg_set_6be42768c690e380(arg0, arg1, arg2) {
    arg0[arg1] = arg2;
  }
  function __wbg_set_6c60b2e8ad0e9383(arg0, arg1, arg2) {
    arg0[arg1 >>> 0] = arg2;
  }
  function __wbg_set_8ee2d34facb8466e() {
    return handleError(function(arg0, arg1, arg2) {
      const ret = Reflect.set(arg0, arg1, arg2);
      return ret;
    }, arguments);
  }
  function __wbg_value_7f6052747ccf940f(arg0) {
    const ret = arg0.value;
    return ret;
  }
  function __wbindgen_cast_0000000000000001(arg0) {
    const ret = arg0;
    return ret;
  }
  function __wbindgen_cast_0000000000000002(arg0, arg1) {
    const ret = getStringFromWasm0(arg0, arg1);
    return ret;
  }
  function __wbindgen_cast_0000000000000003(arg0) {
    const ret = BigInt.asUintN(64, arg0);
    return ret;
  }
  function __wbindgen_init_externref_table() {
    const table = wasm.__wbindgen_externrefs;
    const offset = table.grow(4);
    table.set(0, void 0);
    table.set(offset + 0, void 0);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
  }
  function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
  }
  function debugString(val) {
    const type = typeof val;
    if (type == "number" || type == "boolean" || val == null) {
      return `${val}`;
    }
    if (type == "string") {
      return `"${val}"`;
    }
    if (type == "symbol") {
      const description = val.description;
      if (description == null) {
        return "Symbol";
      } else {
        return `Symbol(${description})`;
      }
    }
    if (type == "function") {
      const name = val.name;
      if (typeof name == "string" && name.length > 0) {
        return `Function(${name})`;
      } else {
        return "Function";
      }
    }
    if (Array.isArray(val)) {
      const length = val.length;
      let debug = "[";
      if (length > 0) {
        debug += debugString(val[0]);
      }
      for (let i = 1; i < length; i++) {
        debug += ", " + debugString(val[i]);
      }
      debug += "]";
      return debug;
    }
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
      className = builtInMatches[1];
    } else {
      return toString.call(val);
    }
    if (className == "Object") {
      try {
        return "Object(" + JSON.stringify(val) + ")";
      } catch (_) {
        return "Object";
      }
    }
    if (val instanceof Error) {
      return `${val.name}: ${val.message}
${val.stack}`;
    }
    return className;
  }
  function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
  }
  var cachedDataViewMemory0 = null;
  function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
      cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
  }
  function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
  }
  var cachedUint8ArrayMemory0 = null;
  function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
      cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
  }
  function handleError(f, args) {
    try {
      return f.apply(this, args);
    } catch (e) {
      const idx = addToExternrefTable0(e);
      wasm.__wbindgen_exn_store(idx);
    }
  }
  function isLikeNone(x) {
    return x === void 0 || x === null;
  }
  function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === void 0) {
      const buf = cachedTextEncoder.encode(arg);
      const ptr2 = malloc(buf.length, 1) >>> 0;
      getUint8ArrayMemory0().subarray(ptr2, ptr2 + buf.length).set(buf);
      WASM_VECTOR_LEN = buf.length;
      return ptr2;
    }
    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;
    const mem = getUint8ArrayMemory0();
    let offset = 0;
    for (; offset < len; offset++) {
      const code = arg.charCodeAt(offset);
      if (code > 127) break;
      mem[ptr + offset] = code;
    }
    if (offset !== len) {
      if (offset !== 0) {
        arg = arg.slice(offset);
      }
      ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
      const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
      const ret = cachedTextEncoder.encodeInto(arg, view);
      offset += ret.written;
      ptr = realloc(ptr, len, offset, 1) >>> 0;
    }
    WASM_VECTOR_LEN = offset;
    return ptr;
  }
  function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
  }
  var cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
  cachedTextDecoder.decode();
  var MAX_SAFARI_DECODE_BYTES = 2146435072;
  var numBytesDecoded = 0;
  function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
      cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
      cachedTextDecoder.decode();
      numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
  }
  var cachedTextEncoder = new TextEncoder();
  if (!("encodeInto" in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function(arg, view) {
      const buf = cachedTextEncoder.encode(arg);
      view.set(buf);
      return {
        read: arg.length,
        written: buf.length
      };
    };
  }
  var WASM_VECTOR_LEN = 0;
  var wasm;
  function __wbg_set_wasm(val) {
    wasm = val;
  }

  // src/vastlint/validator.ts
  var initPromise = null;
  async function ensureInit() {
    if (initPromise) return initPromise;
    initPromise = (async () => {
      const binaryUrl = chrome.runtime.getURL("vastlint_wasm_bg.wasm");
      const importObject = {};
      for (const [key, val] of Object.entries(vastlint_wasm_bg_exports)) {
        if (typeof val === "function" && (key.startsWith("__wbg_") || key.startsWith("__wbindgen_"))) {
          importObject["./vastlint_wasm_bg.js"] ??= {};
          importObject["./vastlint_wasm_bg.js"][key] = val;
        }
      }
      const { instance } = await WebAssembly.instantiateStreaming(
        fetch(binaryUrl),
        importObject
      );
      __wbg_set_wasm(instance.exports);
      const start = instance.exports.__wbindgen_start;
      start?.();
    })();
    return initPromise;
  }
  async function validateVast(xml) {
    await ensureInit();
    return validate(xml);
  }

  // src/analysis/analysis.ts
  function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function countNL(s) {
    let n = 0;
    for (let i = 0; i < s.length; i++) if (s[i] === "\n") n++;
    return n;
  }
  function highlightXml(raw, lineIssues) {
    let out = "";
    let i = 0;
    let curLine = 1;
    const squiggled = /* @__PURE__ */ new Set();
    function sq(html, startLine, chunk) {
      if (!lineIssues || squiggled.has(startLine) || chunk.includes("\n")) return html;
      const issues = lineIssues.get(startLine);
      if (!issues) return html;
      squiggled.add(startLine);
      const sev = issues[0].severity;
      return `<span class="sq sq-${sev}">${html}</span>`;
    }
    while (i < raw.length) {
      if (raw.startsWith("<!--", i)) {
        const end = raw.indexOf("-->", i + 4);
        const chunk = end === -1 ? raw.slice(i) : raw.slice(i, end + 3);
        const sl = curLine;
        curLine += countNL(chunk);
        out += sq(`<span class="xt-comment">${esc(chunk)}</span>`, sl, chunk);
        i += chunk.length;
        continue;
      }
      if (raw.startsWith("<![CDATA[", i)) {
        const end = raw.indexOf("]]>", i + 9);
        const chunk = end === -1 ? raw.slice(i) : raw.slice(i, end + 3);
        const sl = curLine;
        curLine += countNL(chunk);
        out += sq(`<span class="xt-cdata">${esc(chunk)}</span>`, sl, chunk);
        i += chunk.length;
        continue;
      }
      if (raw.startsWith("<?", i)) {
        const end = raw.indexOf("?>", i + 2);
        const chunk = end === -1 ? raw.slice(i) : raw.slice(i, end + 2);
        const sl = curLine;
        curLine += countNL(chunk);
        out += sq(`<span class="xt-pi">${esc(chunk)}</span>`, sl, chunk);
        i += chunk.length;
        continue;
      }
      if (raw[i] === "<") {
        let j2 = i + 1;
        let inQuote = "";
        while (j2 < raw.length) {
          const c = raw[j2];
          if (inQuote) {
            if (c === inQuote) inQuote = "";
          } else if (c === '"' || c === "'") {
            inQuote = c;
          } else if (c === ">") {
            j2++;
            break;
          }
          j2++;
        }
        const chunk = raw.slice(i, j2);
        const sl = curLine;
        curLine += countNL(chunk);
        out += sq(colorizeTag(chunk), sl, chunk);
        i = j2;
        continue;
      }
      if (raw[i] === "&") {
        const end = raw.indexOf(";", i);
        if (end !== -1 && end - i < 16) {
          out += `<span class="xt-entity">${esc(raw.slice(i, end + 1))}</span>`;
          i = end + 1;
          continue;
        }
      }
      let j = i + 1;
      while (j < raw.length && raw[j] !== "<" && raw[j] !== "&") j++;
      const text = raw.slice(i, j);
      curLine += countNL(text);
      out += esc(text);
      i = j;
    }
    return out;
  }
  function p(s) {
    return s ? `<span class="xt-punct">${esc(s)}</span>` : "";
  }
  function t(s) {
    return s ? `<span class="xt-tag">${esc(s)}</span>` : "";
  }
  function colorizeAttrs(chunk) {
    return chunk.replace(
      /([\w:\-\.]+)(\s*=\s*)(["'])((?:[^"'\\]|\\.)*)(\3)|([\w:\-\.]+)|(\s+)/g,
      (_, aName, eq, q, val, _q2, bare, ws) => {
        if (ws) return esc(ws);
        if (bare) return `<span class="xt-attr">${esc(bare)}</span>`;
        if (aName) return `<span class="xt-attr">${esc(aName)}</span>` + p(eq ?? "") + p(q) + `<span class="xt-val">${esc(val ?? "")}</span>` + p(q);
        return "";
      }
    );
  }
  function colorizeTag(tag) {
    const closeM = tag.match(/^(<\/)([\w:\-\.]+)(>)$/);
    if (closeM) return p(closeM[1]) + t(closeM[2]) + p(closeM[3]);
    let i = 1;
    let out = p("<");
    if (tag[i] === "/") {
      out += p("/");
      i++;
    }
    const nameStart = i;
    while (i < tag.length && !/[ \/>\n\t]/.test(tag[i])) i++;
    out += t(tag.slice(nameStart, i));
    const tail = tag.slice(i);
    const isSelfClose = tail.trimEnd().endsWith("/>");
    const inner = tail.slice(0, tail.lastIndexOf(isSelfClose ? "/>" : ">"));
    out += colorizeAttrs(inner);
    out += p(isSelfClose ? "/>" : ">");
    return out;
  }
  var xmlInput = document.getElementById("xml-input");
  var xmlLineHlWrap = document.getElementById("xml-line-hl-wrap");
  var xmlLineHlInner = document.getElementById("xml-line-hl-inner");
  var xmlHlCode = document.getElementById("xml-hl-code");
  var xmlHl = document.getElementById("xml-hl");
  var analyzeBtn = document.getElementById("analyze-btn");
  var analyzingInd = document.getElementById("analyzing-indicator");
  var charCount = document.getElementById("char-count");
  var topbarTitle = document.getElementById("topbar-title");
  var topbarPills = document.getElementById("topbar-pills");
  var resultsHdr = document.getElementById("results-hdr");
  var resultsHdrLbl = document.getElementById("results-hdr-label");
  var filterBar = document.getElementById("filter-bar");
  var loadingState = document.getElementById("loading-state");
  var emptyState = document.getElementById("results-empty");
  var issueList = document.getElementById("issue-list");
  var cleanState = document.getElementById("clean-state");
  var xmlTooltip = document.getElementById("xml-tooltip");
  var currentLineIssueMap = /* @__PURE__ */ new Map();
  var SEV_COLOR = {
    error: "#ef4444",
    warning: "#f59e0b",
    info: "#818cf8"
  };
  function showTooltip(clientX, clientY, issues) {
    const topSev = issues[0].severity;
    const color = SEV_COLOR[topSev] ?? "#8aa7c8";
    xmlTooltip.innerHTML = issues.map((iss) => `
    <div class="tip-row">
      <div class="tip-meta">
        <a class="tip-id" href="https://vastlint.org/docs/rules/${encodeURIComponent(iss.id)}"
           target="_blank" rel="noopener">${esc(iss.id)}</a>
        ${iss.line ? `<span class="tip-line">line ${iss.line}</span>` : ""}
      </div>
      <div class="tip-msg">${esc(iss.message)}</div>
    </div>`).join("");
    xmlTooltip.style.borderColor = color;
    xmlTooltip.style.display = "block";
    const TIP_W = 320;
    const TIP_OFFSET = 12;
    let left = clientX - TIP_W / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - TIP_W - 8));
    xmlTooltip.style.left = `${left}px`;
    xmlTooltip.style.top = "0px";
    const h = xmlTooltip.offsetHeight;
    const top = clientY - h - TIP_OFFSET;
    xmlTooltip.style.top = `${top < 8 ? clientY + TIP_OFFSET : top}px`;
  }
  function hideTooltip() {
    xmlTooltip.style.display = "none";
  }
  function updateHighlight() {
    xmlHlCode.innerHTML = highlightXml(xmlInput.value, currentLineIssueMap.size ? currentLineIssueMap : void 0) + "\n";
  }
  xmlInput.addEventListener("input", () => {
    updateHighlight();
    const len = xmlInput.value.length;
    charCount.textContent = len > 0 ? `${len.toLocaleString()} chars` : "";
    scheduleAnalysis();
  });
  xmlInput.addEventListener("paste", () => {
    setTimeout(() => {
      updateHighlight();
      const len = xmlInput.value.length;
      charCount.textContent = len > 0 ? `${len.toLocaleString()} chars` : "";
      scheduleAnalysis(0);
    }, 0);
  });
  var analyzeTimer = null;
  function scheduleAnalysis(delay = 600) {
    if (analyzeTimer) clearTimeout(analyzeTimer);
    analyzeTimer = setTimeout(() => {
      analyzeTimer = null;
      runAnalysis();
    }, delay);
  }
  xmlInput.addEventListener("scroll", () => {
    xmlHl.scrollTop = xmlInput.scrollTop;
    xmlHl.scrollLeft = xmlInput.scrollLeft;
    xmlLineHlWrap.scrollTop = xmlInput.scrollTop;
    xmlLineHlWrap.scrollLeft = xmlInput.scrollLeft;
  });
  xmlInput.addEventListener("mousemove", (e) => {
    if (!currentLineIssueMap.size) return;
    const line = Math.floor((e.offsetY + xmlInput.scrollTop - PAD_TOP) / LINE_H) + 1;
    const issues = currentLineIssueMap.get(line);
    if (!issues) {
      hideTooltip();
      return;
    }
    const visible = issues.filter((iss) => activeFilters.has(iss.severity));
    if (!visible.length) {
      hideTooltip();
      return;
    }
    showTooltip(e.clientX, e.clientY, visible);
  });
  xmlInput.addEventListener("mouseleave", hideTooltip);
  var LINE_H = 12.5 * 1.65;
  var PAD_TOP = 16;
  function applyLineHighlights(lineMap) {
    xmlLineHlInner.innerHTML = "";
    const totalLines = xmlInput.value.split("\n").length;
    xmlLineHlInner.style.height = `${PAD_TOP + totalLines * LINE_H + PAD_TOP}px`;
    for (const [line, sev] of lineMap) {
      const div = document.createElement("div");
      div.className = `xl-line ${sev}`;
      div.dataset.sev = sev;
      div.style.top = `${PAD_TOP + (line - 1) * LINE_H}px`;
      xmlLineHlInner.appendChild(div);
    }
  }
  var activeFilters = /* @__PURE__ */ new Set(["error", "warning", "info"]);
  filterBar.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const sev = btn.dataset.sev;
      if (activeFilters.has(sev)) {
        activeFilters.delete(sev);
        btn.classList.remove("active");
      } else {
        activeFilters.add(sev);
        btn.classList.add("active");
      }
      applyFilters();
    });
  });
  function applyFilters() {
    issueList.querySelectorAll(".issue-card").forEach((el) => {
      el.classList.toggle("hidden", !activeFilters.has(el.dataset.sev ?? ""));
    });
    issueList.querySelectorAll(".issue-group").forEach((grp) => {
      const visible = grp.querySelectorAll(".issue-card:not(.hidden)").length > 0;
      grp.style.display = visible ? "" : "none";
    });
    xmlLineHlInner.querySelectorAll(".xl-line").forEach((el) => {
      el.style.display = activeFilters.has(el.dataset.sev ?? "") ? "block" : "none";
    });
  }
  analyzeBtn.addEventListener("click", () => runAnalysis());
  async function runAnalysis() {
    const xml = xmlInput.value.trim();
    if (!xml) return;
    analyzeBtn.disabled = true;
    analyzingInd.style.display = "inline";
    loadingState.style.display = "flex";
    emptyState.style.display = "none";
    issueList.style.display = "none";
    cleanState.style.display = "none";
    topbarPills.innerHTML = "";
    resultsHdr.style.display = "none";
    filterBar.classList.remove("visible");
    currentLineIssueMap = /* @__PURE__ */ new Map();
    updateHighlight();
    hideTooltip();
    let result;
    try {
      result = await validateVast(xml);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      loadingState.style.display = "none";
      issueList.style.display = "block";
      issueList.innerHTML = `<div style="padding:20px;color:#ef5350;font-size:13px;"><strong>\u26A0 Validation error</strong><br><br>${esc(msg)}</div>`;
      analyzeBtn.disabled = false;
      analyzingInd.style.display = "none";
      return;
    }
    analyzeBtn.disabled = false;
    analyzingInd.style.display = "none";
    loadingState.style.display = "none";
    renderResults(result);
  }
  function renderResults(result) {
    const { errors, warnings, infos } = result.summary;
    const total = errors + warnings + infos;
    topbarPills.innerHTML = [
      errors > 0 ? `<span class="tpill tpill-err">${errors}E</span>` : "",
      warnings > 0 ? `<span class="tpill tpill-warn">${warnings}W</span>` : "",
      infos > 0 ? `<span class="tpill tpill-info">${infos}I</span>` : "",
      total === 0 ? `<span class="tpill tpill-ok">\u2713 Clean</span>` : "",
      result.version ? `<span class="ver-pill">VAST ${esc(result.version)}</span>` : ""
    ].filter(Boolean).join("");
    topbarTitle.innerHTML = total > 0 ? `Found <strong>${total} issue${total !== 1 ? "s" : ""}</strong>` : "<strong>No issues found</strong>";
    resultsHdr.style.display = "flex";
    resultsHdrLbl.textContent = total > 0 ? `${total} issue${total !== 1 ? "s" : ""}` : "Results";
    if (total === 0) {
      cleanState.style.display = "flex";
      issueList.style.display = "none";
      filterBar.classList.remove("visible");
      currentLineIssueMap = /* @__PURE__ */ new Map();
      updateHighlight();
      applyLineHighlights(/* @__PURE__ */ new Map());
      return;
    }
    filterBar.classList.add("visible");
    const grouped = { error: [], warning: [], info: [] };
    for (const iss of result.issues) (grouped[iss.severity] ?? grouped["info"]).push(iss);
    const groupCount = {
      error: "error",
      warning: "warning",
      info: "advisory"
    };
    issueList.innerHTML = ["error", "warning", "info"].filter((sev) => grouped[sev].length > 0).map((sev) => {
      const n = grouped[sev].length;
      const items = grouped[sev].map((iss) => {
        const pathShort = iss.path ? iss.path.split("/").slice(-2).join("/") : null;
        const meta = [
          `<a class="iss-id" href="https://vastlint.org/docs/rules/${encodeURIComponent(iss.id)}" target="_blank" rel="noopener">${esc(iss.id)}</a>`,
          pathShort ? `<span class="iss-path" title="${esc(iss.path ?? "")}">${esc(pathShort)}</span>` : "",
          iss.line ? `<span class="iss-line">line ${iss.line}</span>` : ""
        ].filter(Boolean).join("");
        return `<div class="issue-card sev-${iss.severity}" data-sev="${iss.severity}">
          <div class="iss-meta">${meta}</div>
          <div class="iss-msg">${esc(iss.message)}</div>
          ${iss.spec_ref ? `<div class="iss-spec">${esc(iss.spec_ref)}</div>` : ""}
        </div>`;
      }).join("");
      return `<div class="issue-group">
        <div class="issue-group-hdr">
          <span class="sev-badge sev-badge-${sev}">${sev.toUpperCase()}</span>
          <span class="group-count">${n} ${groupCount[sev]}${n !== 1 ? "s" : ""}</span>
        </div>
        <div class="issue-group-items">${items}</div>
      </div>`;
    }).join("");
    issueList.style.display = "block";
    cleanState.style.display = "none";
    const sevOrder = { error: 3, warning: 2, info: 1 };
    currentLineIssueMap = /* @__PURE__ */ new Map();
    for (const iss of result.issues) {
      if (!iss.line) continue;
      if (!currentLineIssueMap.has(iss.line)) currentLineIssueMap.set(iss.line, []);
      currentLineIssueMap.get(iss.line).push(iss);
    }
    for (const arr of currentLineIssueMap.values()) {
      arr.sort((a, b) => (sevOrder[b.severity] ?? 0) - (sevOrder[a.severity] ?? 0));
    }
    updateHighlight();
    const bgLineMap = /* @__PURE__ */ new Map();
    for (const [line, arr] of currentLineIssueMap) bgLineMap.set(line, arr[0].severity);
    applyLineHighlights(bgLineMap);
    applyFilters();
  }
  async function init() {
    validateVast("<VAST/>").catch(() => {
    });
    try {
      const stored = await chrome.storage.session.get("paste_xml");
      const xml = stored["paste_xml"];
      if (xml) {
        xmlInput.value = xml;
        updateHighlight();
        charCount.textContent = `${xml.length.toLocaleString()} chars`;
        await chrome.storage.session.remove("paste_xml");
        runAnalysis();
      }
    } catch {
    }
  }
  init();
})();
