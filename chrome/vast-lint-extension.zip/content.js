"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../npm/vastlint_wasm_bg.js
  var vastlint_wasm_bg_exports = {};
  __export(vastlint_wasm_bg_exports, {
    __wbg_Error_2e59b1b37a9a34c3: () => __wbg_Error_2e59b1b37a9a34c3,
    __wbg_Number_e6ffdb596c888833: () => __wbg_Number_e6ffdb596c888833,
    __wbg_String_8564e559799eccda: () => __wbg_String_8564e559799eccda,
    __wbg___wbindgen_boolean_get_a86c216575a75c30: () => __wbg___wbindgen_boolean_get_a86c216575a75c30,
    __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57: () => __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57,
    __wbg___wbindgen_in_4bd7a57e54337366: () => __wbg___wbindgen_in_4bd7a57e54337366,
    __wbg___wbindgen_is_function_49868bde5eb1e745: () => __wbg___wbindgen_is_function_49868bde5eb1e745,
    __wbg___wbindgen_is_null_344c8750a8525473: () => __wbg___wbindgen_is_null_344c8750a8525473,
    __wbg___wbindgen_is_object_40c5a80572e8f9d3: () => __wbg___wbindgen_is_object_40c5a80572e8f9d3,
    __wbg___wbindgen_is_undefined_c0cca72b82b86f4d: () => __wbg___wbindgen_is_undefined_c0cca72b82b86f4d,
    __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944: () => __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944,
    __wbg___wbindgen_number_get_7579aab02a8a620c: () => __wbg___wbindgen_number_get_7579aab02a8a620c,
    __wbg___wbindgen_string_get_914df97fcfa788f2: () => __wbg___wbindgen_string_get_914df97fcfa788f2,
    __wbg___wbindgen_throw_81fc77679af83bc6: () => __wbg___wbindgen_throw_81fc77679af83bc6,
    __wbg_call_7f2987183bb62793: () => __wbg_call_7f2987183bb62793,
    __wbg_done_547d467e97529006: () => __wbg_done_547d467e97529006,
    __wbg_entries_616b1a459b85be0b: () => __wbg_entries_616b1a459b85be0b,
    __wbg_from_741da0f916ab74aa: () => __wbg_from_741da0f916ab74aa,
    __wbg_get_4848e350b40afc16: () => __wbg_get_4848e350b40afc16,
    __wbg_get_ed0642c4b9d31ddf: () => __wbg_get_ed0642c4b9d31ddf,
    __wbg_get_f96702c6245e4ef9: () => __wbg_get_f96702c6245e4ef9,
    __wbg_get_unchecked_7d7babe32e9e6a54: () => __wbg_get_unchecked_7d7babe32e9e6a54,
    __wbg_get_with_ref_key_6412cf3094599694: () => __wbg_get_with_ref_key_6412cf3094599694,
    __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a: () => __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a,
    __wbg_instanceof_Uint8Array_4b8da683deb25d72: () => __wbg_instanceof_Uint8Array_4b8da683deb25d72,
    __wbg_isSafeInteger_ea83862ba994770c: () => __wbg_isSafeInteger_ea83862ba994770c,
    __wbg_iterator_de403ef31815a3e6: () => __wbg_iterator_de403ef31815a3e6,
    __wbg_length_0c32cb8543c8e4c8: () => __wbg_length_0c32cb8543c8e4c8,
    __wbg_length_6e821edde497a532: () => __wbg_length_6e821edde497a532,
    __wbg_new_4f9fafbb3909af72: () => __wbg_new_4f9fafbb3909af72,
    __wbg_new_a560378ea1240b14: () => __wbg_new_a560378ea1240b14,
    __wbg_new_f3c9df4f38f3f798: () => __wbg_new_f3c9df4f38f3f798,
    __wbg_next_01132ed6134b8ef5: () => __wbg_next_01132ed6134b8ef5,
    __wbg_next_b3713ec761a9dbfd: () => __wbg_next_b3713ec761a9dbfd,
    __wbg_prototypesetcall_3e05eb9545565046: () => __wbg_prototypesetcall_3e05eb9545565046,
    __wbg_set_6be42768c690e380: () => __wbg_set_6be42768c690e380,
    __wbg_set_6c60b2e8ad0e9383: () => __wbg_set_6c60b2e8ad0e9383,
    __wbg_set_8ee2d34facb8466e: () => __wbg_set_8ee2d34facb8466e,
    __wbg_set_wasm: () => __wbg_set_wasm,
    __wbg_value_7f6052747ccf940f: () => __wbg_value_7f6052747ccf940f,
    __wbindgen_cast_0000000000000001: () => __wbindgen_cast_0000000000000001,
    __wbindgen_cast_0000000000000002: () => __wbindgen_cast_0000000000000002,
    __wbindgen_cast_0000000000000003: () => __wbindgen_cast_0000000000000003,
    __wbindgen_init_externref_table: () => __wbindgen_init_externref_table,
    fix: () => fix,
    fixWithOptions: () => fixWithOptions,
    rules: () => rules,
    validate: () => validate,
    validateWithOptions: () => validateWithOptions
  });
  function fix(xml) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.fix(ptr0, len0);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function fixWithOptions(xml, options) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.fixWithOptions(ptr0, len0, options);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function rules() {
    const ret = wasm.rules();
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function validate(xml) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validate(ptr0, len0);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function validateWithOptions(xml, options) {
    const ptr0 = passStringToWasm0(xml, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWithOptions(ptr0, len0, options);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
  }
  function __wbg_Error_2e59b1b37a9a34c3(arg0, arg1) {
    const ret = Error(getStringFromWasm0(arg0, arg1));
    return ret;
  }
  function __wbg_Number_e6ffdb596c888833(arg0) {
    const ret = Number(arg0);
    return ret;
  }
  function __wbg_String_8564e559799eccda(arg0, arg1) {
    const ret = String(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  }
  function __wbg___wbindgen_boolean_get_a86c216575a75c30(arg0) {
    const v = arg0;
    const ret = typeof v === "boolean" ? v : void 0;
    return isLikeNone(ret) ? 16777215 : ret ? 1 : 0;
  }
  function __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57(arg0, arg1) {
    const ret = debugString(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  }
  function __wbg___wbindgen_in_4bd7a57e54337366(arg0, arg1) {
    const ret = arg0 in arg1;
    return ret;
  }
  function __wbg___wbindgen_is_function_49868bde5eb1e745(arg0) {
    const ret = typeof arg0 === "function";
    return ret;
  }
  function __wbg___wbindgen_is_null_344c8750a8525473(arg0) {
    const ret = arg0 === null;
    return ret;
  }
  function __wbg___wbindgen_is_object_40c5a80572e8f9d3(arg0) {
    const val = arg0;
    const ret = typeof val === "object" && val !== null;
    return ret;
  }
  function __wbg___wbindgen_is_undefined_c0cca72b82b86f4d(arg0) {
    const ret = arg0 === void 0;
    return ret;
  }
  function __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944(arg0, arg1) {
    const ret = arg0 == arg1;
    return ret;
  }
  function __wbg___wbindgen_number_get_7579aab02a8a620c(arg0, arg1) {
    const obj = arg1;
    const ret = typeof obj === "number" ? obj : void 0;
    getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
  }
  function __wbg___wbindgen_string_get_914df97fcfa788f2(arg0, arg1) {
    const obj = arg1;
    const ret = typeof obj === "string" ? obj : void 0;
    var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  }
  function __wbg___wbindgen_throw_81fc77679af83bc6(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
  }
  function __wbg_call_7f2987183bb62793() {
    return handleError(function(arg0, arg1) {
      const ret = arg0.call(arg1);
      return ret;
    }, arguments);
  }
  function __wbg_done_547d467e97529006(arg0) {
    const ret = arg0.done;
    return ret;
  }
  function __wbg_entries_616b1a459b85be0b(arg0) {
    const ret = Object.entries(arg0);
    return ret;
  }
  function __wbg_from_741da0f916ab74aa(arg0) {
    const ret = Array.from(arg0);
    return ret;
  }
  function __wbg_get_4848e350b40afc16(arg0, arg1) {
    const ret = arg0[arg1 >>> 0];
    return ret;
  }
  function __wbg_get_ed0642c4b9d31ddf() {
    return handleError(function(arg0, arg1) {
      const ret = Reflect.get(arg0, arg1);
      return ret;
    }, arguments);
  }
  function __wbg_get_f96702c6245e4ef9() {
    return handleError(function(arg0, arg1) {
      const ret = Reflect.get(arg0, arg1);
      return ret;
    }, arguments);
  }
  function __wbg_get_unchecked_7d7babe32e9e6a54(arg0, arg1) {
    const ret = arg0[arg1 >>> 0];
    return ret;
  }
  function __wbg_get_with_ref_key_6412cf3094599694(arg0, arg1) {
    const ret = arg0[arg1];
    return ret;
  }
  function __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a(arg0) {
    let result;
    try {
      result = arg0 instanceof ArrayBuffer;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  }
  function __wbg_instanceof_Uint8Array_4b8da683deb25d72(arg0) {
    let result;
    try {
      result = arg0 instanceof Uint8Array;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  }
  function __wbg_isSafeInteger_ea83862ba994770c(arg0) {
    const ret = Number.isSafeInteger(arg0);
    return ret;
  }
  function __wbg_iterator_de403ef31815a3e6() {
    const ret = Symbol.iterator;
    return ret;
  }
  function __wbg_length_0c32cb8543c8e4c8(arg0) {
    const ret = arg0.length;
    return ret;
  }
  function __wbg_length_6e821edde497a532(arg0) {
    const ret = arg0.length;
    return ret;
  }
  function __wbg_new_4f9fafbb3909af72() {
    const ret = new Object();
    return ret;
  }
  function __wbg_new_a560378ea1240b14(arg0) {
    const ret = new Uint8Array(arg0);
    return ret;
  }
  function __wbg_new_f3c9df4f38f3f798() {
    const ret = new Array();
    return ret;
  }
  function __wbg_next_01132ed6134b8ef5(arg0) {
    const ret = arg0.next;
    return ret;
  }
  function __wbg_next_b3713ec761a9dbfd() {
    return handleError(function(arg0) {
      const ret = arg0.next();
      return ret;
    }, arguments);
  }
  function __wbg_prototypesetcall_3e05eb9545565046(arg0, arg1, arg2) {
    Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
  }
  function __wbg_set_6be42768c690e380(arg0, arg1, arg2) {
    arg0[arg1] = arg2;
  }
  function __wbg_set_6c60b2e8ad0e9383(arg0, arg1, arg2) {
    arg0[arg1 >>> 0] = arg2;
  }
  function __wbg_set_8ee2d34facb8466e() {
    return handleError(function(arg0, arg1, arg2) {
      const ret = Reflect.set(arg0, arg1, arg2);
      return ret;
    }, arguments);
  }
  function __wbg_value_7f6052747ccf940f(arg0) {
    const ret = arg0.value;
    return ret;
  }
  function __wbindgen_cast_0000000000000001(arg0) {
    const ret = arg0;
    return ret;
  }
  function __wbindgen_cast_0000000000000002(arg0, arg1) {
    const ret = getStringFromWasm0(arg0, arg1);
    return ret;
  }
  function __wbindgen_cast_0000000000000003(arg0) {
    const ret = BigInt.asUintN(64, arg0);
    return ret;
  }
  function __wbindgen_init_externref_table() {
    const table = wasm.__wbindgen_externrefs;
    const offset = table.grow(4);
    table.set(0, void 0);
    table.set(offset + 0, void 0);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
  }
  function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
  }
  function debugString(val) {
    const type = typeof val;
    if (type == "number" || type == "boolean" || val == null) {
      return `${val}`;
    }
    if (type == "string") {
      return `"${val}"`;
    }
    if (type == "symbol") {
      const description = val.description;
      if (description == null) {
        return "Symbol";
      } else {
        return `Symbol(${description})`;
      }
    }
    if (type == "function") {
      const name = val.name;
      if (typeof name == "string" && name.length > 0) {
        return `Function(${name})`;
      } else {
        return "Function";
      }
    }
    if (Array.isArray(val)) {
      const length = val.length;
      let debug = "[";
      if (length > 0) {
        debug += debugString(val[0]);
      }
      for (let i = 1; i < length; i++) {
        debug += ", " + debugString(val[i]);
      }
      debug += "]";
      return debug;
    }
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
      className = builtInMatches[1];
    } else {
      return toString.call(val);
    }
    if (className == "Object") {
      try {
        return "Object(" + JSON.stringify(val) + ")";
      } catch (_) {
        return "Object";
      }
    }
    if (val instanceof Error) {
      return `${val.name}: ${val.message}
${val.stack}`;
    }
    return className;
  }
  function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
  }
  function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
      cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
  }
  function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
  }
  function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
      cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
  }
  function handleError(f, args) {
    try {
      return f.apply(this, args);
    } catch (e) {
      const idx = addToExternrefTable0(e);
      wasm.__wbindgen_exn_store(idx);
    }
  }
  function isLikeNone(x) {
    return x === void 0 || x === null;
  }
  function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === void 0) {
      const buf = cachedTextEncoder.encode(arg);
      const ptr2 = malloc(buf.length, 1) >>> 0;
      getUint8ArrayMemory0().subarray(ptr2, ptr2 + buf.length).set(buf);
      WASM_VECTOR_LEN = buf.length;
      return ptr2;
    }
    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;
    const mem = getUint8ArrayMemory0();
    let offset = 0;
    for (; offset < len; offset++) {
      const code = arg.charCodeAt(offset);
      if (code > 127) break;
      mem[ptr + offset] = code;
    }
    if (offset !== len) {
      if (offset !== 0) {
        arg = arg.slice(offset);
      }
      ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
      const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
      const ret = cachedTextEncoder.encodeInto(arg, view);
      offset += ret.written;
      ptr = realloc(ptr, len, offset, 1) >>> 0;
    }
    WASM_VECTOR_LEN = offset;
    return ptr;
  }
  function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
  }
  function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
      cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
      cachedTextDecoder.decode();
      numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
  }
  function __wbg_set_wasm(val) {
    wasm = val;
  }
  var cachedDataViewMemory0, cachedUint8ArrayMemory0, cachedTextDecoder, MAX_SAFARI_DECODE_BYTES, numBytesDecoded, cachedTextEncoder, WASM_VECTOR_LEN, wasm;
  var init_vastlint_wasm_bg = __esm({
    "../npm/vastlint_wasm_bg.js"() {
      cachedDataViewMemory0 = null;
      cachedUint8ArrayMemory0 = null;
      cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
      cachedTextDecoder.decode();
      MAX_SAFARI_DECODE_BYTES = 2146435072;
      numBytesDecoded = 0;
      cachedTextEncoder = new TextEncoder();
      if (!("encodeInto" in cachedTextEncoder)) {
        cachedTextEncoder.encodeInto = function(arg, view) {
          const buf = cachedTextEncoder.encode(arg);
          view.set(buf);
          return {
            read: arg.length,
            written: buf.length
          };
        };
      }
      WASM_VECTOR_LEN = 0;
    }
  });

  // src/vastlint/validator.ts
  var validator_exports = {};
  __export(validator_exports, {
    validateVast: () => validateVast
  });
  async function ensureInit() {
    if (initPromise) return initPromise;
    initPromise = (async () => {
      const binaryUrl = chrome.runtime.getURL("vastlint_wasm_bg.wasm");
      const importObject = {};
      for (const [key, val] of Object.entries(vastlint_wasm_bg_exports)) {
        if (typeof val === "function" && (key.startsWith("__wbg_") || key.startsWith("__wbindgen_"))) {
          importObject["./vastlint_wasm_bg.js"] ??= {};
          importObject["./vastlint_wasm_bg.js"][key] = val;
        }
      }
      const { instance } = await WebAssembly.instantiateStreaming(
        fetch(binaryUrl),
        importObject
      );
      __wbg_set_wasm(instance.exports);
      const start = instance.exports.__wbindgen_start;
      start?.();
    })();
    return initPromise;
  }
  async function validateVast(xml) {
    await ensureInit();
    return validate(xml);
  }
  var initPromise;
  var init_validator = __esm({
    "src/vastlint/validator.ts"() {
      "use strict";
      init_vastlint_wasm_bg();
      initPromise = null;
    }
  });

  // src/content/index.ts
  init_validator();

  // src/content/panel.ts
  var SEV_COLOR = {
    error: "#e53935",
    warning: "#f4a000",
    info: "#1e88e5"
  };
  var SEV_ICON = {
    error: "\u2715",
    warning: "\u26A0",
    info: "\u2139"
  };
  function renderPanel(result, anchor, origToFmt, pathToFmt) {
    const el = anchor;
    el._vlCleanup?.();
    const isCode = anchor.tagName === "PRE" || anchor.tagName === "TEXTAREA" || anchor === document.documentElement;
    if (isCode) {
      renderOverlay(result, anchor, origToFmt, pathToFmt);
    } else {
      renderFloatingPanel(result, null);
    }
  }
  function htmlEl(tag) {
    return document.createElementNS("http://www.w3.org/1999/xhtml", tag);
  }
  function escHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function buildLineIssues(result) {
    const map = /* @__PURE__ */ new Map();
    for (const iss of result.issues) {
      const ln = iss.line ?? 1;
      if (!map.has(ln)) map.set(ln, []);
      map.get(ln).push(iss);
    }
    return map;
  }
  function summaryHTML(result) {
    const { errors, warnings, infos } = result.summary;
    return [
      errors ? `<span class="e">${errors} error${errors !== 1 ? "s" : ""}</span>` : "",
      warnings ? `<span class="w">${warnings} warning${warnings !== 1 ? "s" : ""}</span>` : "",
      infos ? `<span class="i">${infos} info</span>` : "",
      !errors && !warnings && !infos ? '<span class="ok">\u2713 Valid</span>' : ""
    ].filter(Boolean).join('<span class="sep"> \xB7 </span>');
  }
  function issueListHTML(issues) {
    return issues.map((iss) => {
      const color = SEV_COLOR[iss.severity];
      const icon = SEV_ICON[iss.severity];
      const meta = [
        iss.path ? `<code>${escHtml(iss.path)}</code>` : "",
        iss.line ? `line ${iss.line}` : "",
        iss.spec_ref ? `<em>${escHtml(iss.spec_ref)}</em>` : ""
      ].filter(Boolean).join(" \xB7 ");
      const idLink = `<a class="issue-id-link" href="https://vastlint.org/docs/rules/${encodeURIComponent(iss.id)}" target="_blank" rel="noopener">[${escHtml(iss.id)}]</a>`;
      return `<div class="issue" data-sev="${escHtml(iss.severity)}">
      <span class="issue-icon" style="color:${color}">${icon}</span>
      <div>
        <div>${idLink} <span class="issue-msg">${escHtml(iss.message)}</span></div>
        ${meta ? `<div class="issue-meta">${meta}</div>` : ""}
      </div>
    </div>`;
    }).join("");
  }
  function renderOverlay(result, anchor, origToFmt, pathToFmt) {
    const lineIssues = buildLineIssues(result);
    const ownerDoc = anchor.ownerDocument ?? document;
    const ownerWin = ownerDoc.defaultView ?? window;
    const host = ownerDoc.createElementNS("http://www.w3.org/1999/xhtml", "div");
    host.setAttribute("data-vastlint-overlay", "true");
    host.style.cssText = "all:initial;position:fixed;top:0;left:0;width:0;height:0;pointer-events:none;";
    (ownerDoc.body ?? ownerDoc.documentElement).appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>
      * { box-sizing:border-box; }

      /* \u2500\u2500 Summary / mode bar \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
      #bar {
        position:fixed; pointer-events:all;
        display:flex; align-items:center; gap:8px;
        padding:6px 14px; border-radius:0 0 8px 8px;
        background:#0d0d14; color:#eee;
        font:600 13px/1 system-ui,sans-serif;
        box-shadow:0 3px 14px rgba(0,0,0,.7), 0 1px 3px rgba(0,0,0,.5);
        border: 1px solid rgba(255,255,255,.08); border-top:none;
        white-space:nowrap; z-index:2147483647;
      }
      #bar .logo { font-weight:600; opacity:.4; font-size:11px; margin-left:4px; letter-spacing:.03em; }
      #bar .sep  { opacity:.2; font-weight:400; }
      #bar .e    { color:#ff6b6b; font-weight:700; }
      #bar .w    { color:#ffd166; font-weight:700; }
      #bar .i    { color:#74b9ff; font-weight:700; }
      #bar .ok   { color:#55efc4; font-weight:700; }
      .mode-btn {
        padding:4px 10px; border-radius:5px; font-size:12px; font-weight:700;
        cursor:pointer; border:1px solid rgba(255,255,255,.18); color:#999;
        background:rgba(255,255,255,.05); line-height:1.4;
        transition: background .12s, color .12s, border-color .12s;
      }
      .mode-btn:hover { background:rgba(255,255,255,.1); color:#ddd; border-color:rgba(255,255,255,.3); }
      .mode-btn.active { background:rgba(255,255,255,.18); color:#fff; border-color:rgba(255,255,255,.5); }
      .sev-btn {
        padding:4px 8px; border-radius:5px; font-size:12px; font-weight:700;
        cursor:pointer; border:1px solid rgba(255,255,255,.15); color:#666;
        background:rgba(255,255,255,.04); line-height:1.4; min-width:28px; text-align:center;
        transition: background .12s, color .12s, border-color .12s;
      }
      .sev-btn:hover { background:rgba(255,255,255,.1); color:#bbb; border-color:rgba(255,255,255,.3); }
      .sev-btn.active { background:rgba(255,255,255,.14); color:#fff; border-color:rgba(255,255,255,.4); }
      /* When filter is off, hide matching rows/issues */
      #layers.hide-error   .highlight[data-sev="error"],
      #layers.hide-error   .squiggle[data-sev="error"],
      #layers.hide-error   .inline-label[data-sev="error"],
      #layers.hide-warning .highlight[data-sev="warning"],
      #layers.hide-warning .squiggle[data-sev="warning"],
      #layers.hide-warning .inline-label[data-sev="warning"],
      #layers.hide-info    .highlight[data-sev="info"],
      #layers.hide-info    .squiggle[data-sev="info"],
      #layers.hide-info    .inline-label[data-sev="info"] { display:none !important; }
      #float-body.hide-error   .issue[data-sev="error"],
      #float-body.hide-warning .issue[data-sev="warning"],
      #float-body.hide-info    .issue[data-sev="info"] { display:none !important; }
      .bar-close { opacity:.5; font-size:14px; cursor:pointer; margin-left:4px; transition:opacity .12s; }
      .bar-close:hover { opacity:1; }
      #bar-drag {
        font-size:16px; color:#fff; opacity:.35; cursor:grab; user-select:none;
        padding:0 2px; letter-spacing:-1px; transition:opacity .12s;
      }
      #bar-drag:hover { opacity:.8; }
      #bar-drag:active { cursor:grabbing; opacity:1; }
      .ver-badge {
        font-size:11px; color:#7ec8e3; opacity:.8;
        border:1px solid rgba(126,200,227,.3); border-radius:4px;
        padding:2px 7px; line-height:1.4; font-weight:700;
      }

      /* \u2500\u2500 Full-line highlight band \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
      .highlight {
        position:fixed; pointer-events:all; cursor:default;
        background:color-mix(in srgb,var(--c) 28%,transparent);
        border-left:3px solid color-mix(in srgb,var(--c) 90%,transparent);
      }

      /* \u2500\u2500 Squiggly underline \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
      .squiggle {
        position:fixed; pointer-events:none; z-index:1;
        height:4px; overflow:visible;
      }

      /* \u2500\u2500 Inline label (after line text) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
      .inline-label {
        position:fixed; pointer-events:none;
        display:flex; align-items:center;
        font:700 13px/1 'JetBrains Mono','Fira Code','Consolas',monospace;
        color:#ffffff;
        white-space:nowrap;
        padding:0 12px 0 10px;
        background: color-mix(in srgb,var(--c) 90%, #000 10%);
        border-left: 3px solid var(--c);
      }

      /* Tooltip */
      .tooltip {
        position:fixed;
        pointer-events:auto;
        background:#0d0d14; color:#e8e8f0;
        border:1px solid rgba(255,255,255,.1); border-radius:8px;
        padding:0;
        font:400 13px/1.5 system-ui,sans-serif;
        width:max-content;
        max-width:min(400px, calc(100vw - 16px));
        box-shadow:0 12px 40px rgba(0,0,0,.8), 0 2px 8px rgba(0,0,0,.5);
        white-space:normal;
        display:none;
        z-index:2147483645;
      }
      .tip-issue { display:flex; gap:8px; padding:10px 14px; border-bottom:1px solid rgba(255,255,255,.07); }
      .tip-issue:last-child { border-bottom:none; }
      .tip-icon     { flex-shrink:0; font-weight:700; margin-top:1px; }
      .tip-id-link  { font-size:11px; font-weight:700; font-family:ui-monospace,monospace; color:#7ec8e3; text-decoration:none; opacity:1; }
      .tip-id-link:hover { text-decoration:underline; }
      .tip-msg   { color:#f0f0f8; font-weight:600; font-size:13px; margin-top:2px; }
      .tip-meta  { color:#888; font-size:11px; margin-top:4px; line-height:1.4; }
      .tip-meta code { color:#94b8d4; font-family:ui-monospace,monospace; word-break:break-all; }
      .tip-meta em   { font-style:normal; color:#666; }

      /* \u2500\u2500 Floating panel \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
      #float {
        position:fixed; pointer-events:all;
        background:#0d0d14; color:#e8e8f0;
        border:1px solid rgba(255,255,255,.1);
        border-radius:10px; box-shadow:0 16px 48px rgba(0,0,0,.8), 0 2px 8px rgba(0,0,0,.5);
        font:400 13px/1.5 system-ui,sans-serif;
        width:380px; max-height:500px;
        display:flex; flex-direction:column;
        z-index:2147483646;
        display:none;
      }
      #float-hdr {
        display:flex; align-items:center; gap:8px;
        padding:10px 14px; background:#111118; border-radius:10px 10px 0 0;
        cursor:grab; user-select:none; flex-shrink:0;
        border-bottom:1px solid rgba(255,255,255,.08);
        font-weight:700; font-size:13px;
      }
      #float-hdr:active { cursor:grabbing; }
      #float-hdr .logo  { font-weight:500; opacity:.3; font-size:11px; margin-left:auto; }
      #float-hdr .close { opacity:.4; cursor:pointer; font-size:14px; margin-left:6px; transition:opacity .12s; }
      #float-hdr .close:hover { opacity:1; }
      #float-body {
        overflow-y:auto; flex:1; padding:4px 0;
        scrollbar-width:thin; scrollbar-color:rgba(255,255,255,.1) transparent;
      }
      .issue { display:flex; gap:10px; padding:9px 14px; border-bottom:1px solid rgba(255,255,255,.06); font-size:13px; line-height:1.4; }
      .issue:last-child { border-bottom:none; }
      .issue-icon { flex-shrink:0; font-weight:700; margin-top:1px; }
      .issue-id-link { font-size:11px; font-weight:700; font-family:ui-monospace,monospace; color:#7ec8e3; text-decoration:none; }
      .issue-id-link:hover { text-decoration:underline; }
      .issue-msg  { color:#f0f0f8; font-weight:600; margin-top:2px; }
      .issue-meta { color:#888; font-size:11px; margin-top:3px; }
      .issue-meta code { color:#94b8d4; font-family:ui-monospace,monospace; }
      .issue-meta em   { font-style:normal; color:#666; }
    </style>

    <div id="bar">
      <span id="bar-drag" title="Drag to move">\u283F</span>
      <span class="sep">\xB7</span>
      ${summaryHTML(result)}
      ${result.version ? `<span class="ver-badge">VAST ${escHtml(result.version)}</span>` : ""}
      <span class="sep">\xB7</span>
      <button class="sev-btn active" id="flt-e" data-sev="error"   title="Toggle errors">E</button>
      <button class="sev-btn active" id="flt-w" data-sev="warning" title="Toggle warnings">W</button>
      <button class="sev-btn active" id="flt-i" data-sev="info"    title="Toggle infos">I</button>
      <span class="sep">\xB7</span>
      <button class="mode-btn active" id="btn-inline" title="Inline line annotations">inline</button>
      <button class="mode-btn"        id="btn-panel"  title="Floating panel">panel</button>
      <span class="logo">vastlint</span>
      <span class="bar-close" id="bar-close" title="Hide">\u2715</span>
    </div>

    <div id="layers"></div>

    <div id="float">
      <div id="float-hdr">
        ${summaryHTML(result)}
        ${result.version ? `<span style="opacity:.5;font-size:10px;font-weight:400">VAST ${result.version}</span>` : ""}
        <span class="logo">vastlint</span>
        <span class="close" id="float-close">\u2715</span>
      </div>
      <div id="float-body">
        ${result.issues.length === 0 ? '<div style="padding:10px;color:#55efc4">\u2713 No issues found</div>' : issueListHTML(result.issues)}
      </div>
    </div>

    <div class="tooltip" id="tip"></div>
  `;
    const bar = shadow.getElementById("bar");
    const layers = shadow.getElementById("layers");
    const btnInline = shadow.getElementById("btn-inline");
    const btnPanel = shadow.getElementById("btn-panel");
    const barClose = shadow.getElementById("bar-close");
    const barDrag = shadow.getElementById("bar-drag");
    const floatEl = shadow.getElementById("float");
    const floatHdr = shadow.getElementById("float-hdr");
    const floatClose = shadow.getElementById("float-close");
    const floatBody = shadow.getElementById("float-body");
    const tip = shadow.getElementById("tip");
    const inlineLabels = [];
    const highlights = [];
    const squiggles = [];
    for (const [ln, issues] of lineIssues) {
      let showTip2 = function(anchorRect) {
        tip.innerHTML = tipRows;
        tip.style.display = "block";
        const MARGIN = 8;
        const tipH = tip.offsetHeight || 120;
        if (ownerWin.innerHeight - anchorRect.bottom < tipH + MARGIN && anchorRect.top > tipH + MARGIN) {
          tip.style.top = "";
          tip.style.bottom = `${ownerWin.innerHeight - anchorRect.top + 4}px`;
        } else {
          tip.style.bottom = "";
          tip.style.top = `${anchorRect.bottom + 4}px`;
        }
        tip.style.right = "";
        const tipW = tip.offsetWidth || 300;
        const ideal = anchorRect.left;
        const maxLeft = ownerWin.innerWidth - tipW - MARGIN;
        tip.style.left = `${Math.max(MARGIN, Math.min(ideal, maxLeft))}px`;
      }, hideTip2 = function() {
        setTimeout(() => {
          if (!tip.matches(":hover")) tip.style.display = "none";
        }, 120);
      };
      var showTip = showTip2, hideTip = hideTip2;
      const worstSev = issues.find((x) => x.severity === "error")?.severity ?? issues.find((x) => x.severity === "warning")?.severity ?? issues[0]?.severity ?? "info";
      const worstColor = SEV_COLOR[worstSev];
      const worstIcon = SEV_ICON[worstSev];
      const n = issues.length;
      const label = n === 1 ? `${worstIcon} ${issues[0].id}` : `${worstIcon} ${n} issues`;
      const issuePath = issues.find((x) => x.path)?.path ?? "";
      const highlight = htmlEl("div");
      highlight.className = "highlight";
      highlight.style.setProperty("--c", worstColor);
      highlight.dataset.ln = String(ln);
      highlight.dataset.sev = worstSev;
      highlight.dataset.xpath = issuePath;
      layers.appendChild(highlight);
      highlights.push(highlight);
      const squiggle = htmlEl("div");
      squiggle.className = "squiggle";
      squiggle.style.setProperty("--c", worstColor);
      squiggle.dataset.ln = String(ln);
      squiggle.dataset.sev = worstSev;
      squiggle.dataset.xpath = issuePath;
      squiggle.dataset.color = worstColor;
      layers.appendChild(squiggle);
      squiggles.push(squiggle);
      const inlineLabel = htmlEl("div");
      inlineLabel.className = "inline-label";
      inlineLabel.dataset.ln = String(ln);
      inlineLabel.dataset.sev = worstSev;
      inlineLabel.style.setProperty("--c", worstColor);
      inlineLabel.textContent = label;
      layers.appendChild(inlineLabel);
      inlineLabels.push(inlineLabel);
      const tipRows = issues.map((iss) => {
        const color = SEV_COLOR[iss.severity];
        const icon = SEV_ICON[iss.severity];
        const meta = [
          iss.path ? `<code>${escHtml(iss.path)}</code>` : "",
          iss.line ? `line ${iss.line}` : "",
          iss.spec_ref ? `<em>${escHtml(iss.spec_ref)}</em>` : ""
        ].filter(Boolean).join(" \xB7 ");
        const idLink = `<a class="tip-id-link" href="https://vastlint.org/docs/rules/${encodeURIComponent(iss.id)}" target="_blank" rel="noopener">[${escHtml(iss.id)}]</a>`;
        return `<div class="tip-issue">
        <span class="tip-icon" style="color:${color}">${icon}</span>
        <div>
          <div>${idLink} <span class="tip-msg">${escHtml(iss.message)}</span></div>
          ${meta ? `<div class="tip-meta">${meta}</div>` : ""}
        </div>
      </div>`;
      }).join("");
      highlight.addEventListener("mouseenter", () => showTip2(highlight.getBoundingClientRect()));
      highlight.addEventListener("mouseleave", hideTip2);
      tip.addEventListener("mouseleave", () => {
        tip.style.display = "none";
      });
    }
    let mode = "inline";
    function setMode(m) {
      mode = m;
      btnInline.classList.toggle("active", m === "inline");
      btnPanel.classList.toggle("active", m === "panel");
      layers.style.display = m === "inline" ? "" : "none";
      tip.style.display = "none";
      floatEl.style.display = m === "panel" ? "flex" : "none";
      if (m === "panel" && !floatEl.dataset.positioned) {
        const rect = anchor.getBoundingClientRect();
        floatEl.style.top = `${Math.max(8, rect.top)}px`;
        floatEl.style.left = `${Math.min(rect.right + 12, window.innerWidth - 376)}px`;
        floatEl.dataset.positioned = "1";
      }
    }
    btnInline.addEventListener("click", () => setMode("inline"));
    btnPanel.addEventListener("click", () => setMode("panel"));
    ["error", "warning", "info"].forEach((sev) => {
      const btn = shadow.getElementById(`flt-${sev[0]}`);
      if (!btn) return;
      btn.addEventListener("click", () => {
        const hide = `hide-${sev}`;
        const active = btn.classList.toggle("active");
        if (active) {
          layers.classList.remove(hide);
          floatBody?.classList.remove(hide);
        } else {
          layers.classList.add(hide);
          floatBody?.classList.add(hide);
        }
      });
    });
    barClose.addEventListener("click", () => {
      layers.style.display = "none";
      floatEl.style.display = "none";
      tip.style.display = "none";
      bar.style.display = "none";
    });
    floatClose.addEventListener("click", () => setMode("inline"));
    let barDragging = false, barOffX = 0, barOffY = 0, barPinned = false;
    barDrag.addEventListener("mousedown", (e) => {
      barDragging = true;
      barPinned = true;
      const r = bar.getBoundingClientRect();
      barOffX = e.clientX - r.left;
      barOffY = e.clientY - r.top;
      e.preventDefault();
    });
    ownerDoc.addEventListener("mousemove", (e) => {
      if (!barDragging) return;
      bar.style.left = `${e.clientX - barOffX}px`;
      bar.style.top = `${e.clientY - barOffY}px`;
    });
    shadow.addEventListener("mouseup", () => {
      barDragging = false;
    });
    ownerDoc.addEventListener("mouseup", () => {
      barDragging = false;
    });
    let dragOffX = 0, dragOffY = 0, dragging = false;
    floatHdr.addEventListener("mousedown", (e) => {
      dragging = true;
      const r = floatEl.getBoundingClientRect();
      dragOffX = e.clientX - r.left;
      dragOffY = e.clientY - r.top;
      e.preventDefault();
    });
    shadow.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const me = e;
      floatEl.style.left = `${me.clientX - dragOffX}px`;
      floatEl.style.top = `${me.clientY - dragOffY}px`;
      floatEl.style.right = "";
    });
    shadow.addEventListener("mouseup", () => {
      dragging = false;
    });
    ownerDoc.addEventListener("mouseup", () => {
      dragging = false;
    });
    function vastPathToXPath(path) {
      return path.replace(/\[@[^\]]*\]/g, "").replace(/\[(\d+)\]/g, (_, n) => `[${parseInt(n, 10) + 1}]`);
    }
    const isXmlDoc = document.contentType === "text/xml" || document.contentType === "application/xml";
    const xpathCache = /* @__PURE__ */ new Map();
    function elementForPath(path) {
      if (!path) return null;
      if (xpathCache.has(path)) return xpathCache.get(path);
      try {
        const xp = vastPathToXPath(path);
        const res = document.evaluate(xp, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        const el = res.singleNodeValue;
        xpathCache.set(path, el);
        return el;
      } catch {
        xpathCache.set(path, null);
        return null;
      }
    }
    function layout() {
      xpathCache.clear();
      const rect = anchor.getBoundingClientRect();
      const contentRect = rect.width === 0 || rect.height === 0 ? new DOMRect(0, 0, ownerWin.innerWidth, ownerWin.innerHeight) : rect;
      const cs = ownerWin.getComputedStyle(anchor);
      let defaultLh = parseFloat(cs.lineHeight);
      if (isNaN(defaultLh)) defaultLh = parseFloat(cs.fontSize) * 1.5 || 18;
      const pt = parseFloat(cs.paddingTop) || 0;
      const pl = parseFloat(cs.paddingLeft) || 0;
      if (!barPinned) {
        bar.style.top = `${Math.max(0, contentRect.top - 28)}px`;
        bar.style.left = `${contentRect.left + 16}px`;
      }
      for (let i = 0; i < highlights.length; i++) {
        let normalisePath2 = function(p) {
          return p.replace(/\/([A-Za-z][\w:.-]*)(?!\[)/g, "/$1[0]");
        };
        var normalisePath = normalisePath2;
        const inlineLabel = inlineLabels[i];
        const highlight = highlights[i];
        const squiggle = squiggles[i];
        let lineY;
        let lh = defaultLh;
        const ln = parseInt(highlight.dataset.ln, 10);
        const issuePath = highlight.dataset.xpath ?? "";
        let lineSpan = null;
        if (issuePath && pathToFmt) {
          const norm = normalisePath2(issuePath);
          const fmtIdx = pathToFmt.get(norm);
          if (fmtIdx !== void 0) {
            lineSpan = anchor.querySelector(`.ln[data-ln="${fmtIdx}"]`);
          }
          if (!lineSpan) {
            lineSpan = anchor.querySelector(`.ln[data-path="${norm.replace(/"/g, '\\"')}"]`);
          }
        }
        if (!lineSpan) {
          lineSpan = anchor.querySelector(`.ln[data-orig="${ln}"]`);
        }
        const isMiniXml = origToFmt && (() => {
          let maxLine = 0;
          for (const k of origToFmt.keys()) if (k > maxLine) maxLine = k;
          return maxLine <= 5;
        })();
        if (!lineSpan && origToFmt && !isMiniXml) {
          let fmtIdx = origToFmt.get(ln);
          if (fmtIdx === void 0) {
            for (let d = 1; d <= 5 && fmtIdx === void 0; d++) {
              fmtIdx = origToFmt.get(ln - d) ?? origToFmt.get(ln + d);
            }
          }
          if (fmtIdx !== void 0) {
            lineSpan = anchor.querySelector(`.ln[data-ln="${fmtIdx}"]`);
          }
        }
        if (!lineSpan && !origToFmt) {
          lineSpan = anchor.querySelector(`.ln[data-ln="${ln - 1}"]`);
        }
        if (!lineSpan && origToFmt) {
          lineSpan = anchor.querySelector('.ln[data-ln="0"]');
        }
        if (lineSpan) {
          const sr = lineSpan.getBoundingClientRect();
          if (sr.height > 0) {
            lineY = sr.top;
            let bottomY = sr.bottom;
            let next = parseInt(lineSpan.dataset.ln, 10) + 1;
            while (true) {
              const ns = anchor.querySelector(`.ln[data-ln="${next}"]`);
              if (!ns || ns.dataset.orig) break;
              const nr = ns.getBoundingClientRect();
              if (nr.height === 0) break;
              bottomY = nr.bottom;
              next++;
            }
            lh = bottomY - sr.top;
          } else {
            lineY = contentRect.top + pt + (ln - 1) * defaultLh;
          }
        } else if (isXmlDoc && issuePath) {
          const el = elementForPath(issuePath);
          const er = el?.getBoundingClientRect();
          if (er && er.height > 2) {
            lineY = er.top;
            lh = er.height;
          } else {
            lineY = contentRect.top + pt + (ln - 1) * defaultLh;
          }
        } else {
          lineY = contentRect.top + pt + (ln - 1) * lh;
        }
        const inView = lineY + lh > 0 && lineY < ownerWin.innerHeight;
        const show = inView && mode === "inline";
        inlineLabel.style.display = highlight.style.display = squiggle.style.display = show ? "" : "none";
        if (!show) continue;
        highlight.style.left = `${contentRect.left}px`;
        highlight.style.top = `${lineY}px`;
        highlight.style.width = `${contentRect.width}px`;
        highlight.style.height = `${lh}px`;
        const innerSpan = lineSpan?.querySelector("span");
        const innerRect = innerSpan?.getBoundingClientRect();
        const textLeft = innerRect ? innerRect.left : contentRect.left + pl + 8;
        const textRight = innerRect ? innerRect.right : contentRect.left + pl + 200;
        squiggle.style.backgroundImage = "";
        squiggle.style.backgroundRepeat = "";
        squiggle.style.backgroundSize = "";
        squiggle.style.left = `${textLeft}px`;
        squiggle.style.top = `${lineY + lh - 6}px`;
        squiggle.style.width = `${Math.max(0, textRight - textLeft)}px`;
        inlineLabel.style.right = `${Math.max(8, ownerWin.innerWidth - (contentRect.left + contentRect.width))}px`;
        inlineLabel.style.left = "";
        inlineLabel.style.top = `${lineY}px`;
        inlineLabel.style.height = `${lh}px`;
      }
    }
    let rafId = 0;
    function tick() {
      layout();
      rafId = requestAnimationFrame(tick);
    }
    rafId = requestAnimationFrame(tick);
    anchor._vlCleanup = () => {
      cancelAnimationFrame(rafId);
      ownerDoc.removeEventListener("mouseup", () => {
        dragging = false;
      });
      host.remove();
    };
  }
  function renderFloatingPanel(result, anchor) {
    const host = htmlEl("div");
    host.setAttribute("data-vastlint-panel", "true");
    host.style.cssText = "all:initial;position:fixed;top:0;left:0;width:0;height:0;pointer-events:none;";
    (document.body ?? document.documentElement).appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    const { errors, warnings } = result.summary;
    const badgeColor = errors > 0 ? SEV_COLOR.error : warnings > 0 ? SEV_COLOR.warning : "#43a047";
    shadow.innerHTML = `
    <style>
      * { box-sizing:border-box; }
      #float {
        position:fixed; pointer-events:all;
        background:#1a1a2e; color:#eee; border:1px solid #2e2e4e;
        border-radius:8px; box-shadow:0 8px 32px rgba(0,0,0,.6);
        font:400 12px/1.5 system-ui,sans-serif;
        width:360px; max-height:480px; top:60px; right:16px;
        display:flex; flex-direction:column; z-index:2147483647;
      }
      #hdr {
        display:flex; align-items:center; gap:6px;
        padding:7px 10px; background:#0f0f1e; border-radius:8px 8px 0 0;
        cursor:grab; user-select:none; flex-shrink:0;
        border-bottom:1px solid #2e2e4e; font-weight:600; font-size:12px;
      }
      #hdr:active { cursor:grabbing; }
      #hdr .logo  { font-weight:400; opacity:.35; font-size:10px; margin-left:auto; }
      #body { overflow-y:auto; flex:1; padding:4px 0; scrollbar-width:thin; scrollbar-color:#2e2e4e #1a1a2e; }
      .issue { display:flex; gap:8px; padding:6px 10px; border-bottom:1px solid #1e1e30; font-size:11px; line-height:1.4; }
      .issue:last-child { border-bottom:none; }
      .issue-icon { flex-shrink:0; font-weight:700; margin-top:1px; }
      .issue-id-link { font-size:10px; color:#7ec8e3; opacity:.8; text-decoration:none; }
      .issue-id-link:hover { text-decoration:underline; opacity:1; }
      .issue-msg  { color:#fff; font-weight:600; }
      .issue-meta { color:#666; font-size:10px; margin-top:2px; }
      .issue-meta code { color:#7ec8e3; font-family:monospace; }
      .issue-meta em   { font-style:normal; color:#555; }
    </style>
    <div id="float">
      <div id="hdr">
        ${summaryHTML(result)}
        ${result.version ? `<span style="opacity:.5;font-size:10px;font-weight:400">VAST ${result.version}</span>` : ""}
        <span class="logo">vastlint</span>
      </div>
      <div id="body">
        ${result.issues.length === 0 ? '<div style="padding:10px;color:#55efc4">\u2713 No issues found</div>' : issueListHTML(result.issues)}
      </div>
    </div>`;
    const floatEl = shadow.getElementById("float");
    const hdr = shadow.getElementById("hdr");
    let dragOffX = 0, dragOffY = 0, dragging = false;
    hdr.addEventListener("mousedown", (e) => {
      dragging = true;
      const r = floatEl.getBoundingClientRect();
      dragOffX = e.clientX - r.left;
      dragOffY = e.clientY - r.top;
      e.preventDefault();
    });
    shadow.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const me = e;
      floatEl.style.left = `${me.clientX - dragOffX}px`;
      floatEl.style.top = `${me.clientY - dragOffY}px`;
      floatEl.style.right = "";
    });
    const stopDrag = () => {
      dragging = false;
    };
    shadow.addEventListener("mouseup", stopDrag);
    document.addEventListener("mouseup", stopDrag);
    if (anchor) {
      anchor._vlCleanup = () => {
        document.removeEventListener("mouseup", stopDrag);
        host.remove();
      };
    }
  }

  // src/content/xml-viewer.ts
  function tokenise(xml) {
    const tokens = [];
    const re = /<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<\/[\w:.-]+\s*>|<[\w:.-][^>]*\/?>|[^<]+/g;
    let curLine = 1;
    let lastEnd = 0;
    let m;
    while ((m = re.exec(xml)) !== null) {
      const gap = xml.slice(lastEnd, m.index);
      for (const ch of gap) if (ch === "\n") curLine++;
      const origLine = curLine;
      for (const ch of m[0]) if (ch === "\n") curLine++;
      lastEnd = m.index + m[0].length;
      const raw = m[0];
      if (!raw.trim()) {
        tokens.push({ type: "text", raw, origLine });
        continue;
      }
      if (raw.startsWith("<?")) {
        tokens.push({ type: "pi", raw, origLine });
        continue;
      }
      if (raw.startsWith("<!DOCTYPE")) {
        tokens.push({ type: "doctype", raw, origLine });
        continue;
      }
      if (raw.startsWith("<!--")) {
        tokens.push({ type: "comment", raw, origLine });
        continue;
      }
      if (raw.startsWith("<![CDATA[")) {
        tokens.push({ type: "cdata", raw, origLine });
        continue;
      }
      if (raw.startsWith("</")) {
        tokens.push({ type: "close", raw, origLine, tag: raw.match(/<\/([\w:.-]+)/)?.[1] ?? "" });
        continue;
      }
      if (raw.startsWith("<")) {
        const self = raw.endsWith("/>");
        const tagMatch = raw.match(/^<([\w:.-]+)([\s\S]*)>$/);
        const tag = tagMatch?.[1] ?? "";
        const attrs = tagMatch?.[2].trim().replace(/\/$/, "").trim() ?? "";
        tokens.push({ type: self ? "self" : "open", raw, origLine, tag, attrs });
        continue;
      }
      tokens.push({ type: "text", raw, origLine });
    }
    return tokens;
  }
  function formatTag(tag, attrsRaw, self) {
    if (!attrsRaw) return self ? `<${tag}/>` : `<${tag}>`;
    return `<${tag} ${attrsRaw}${self ? "/>" : ">"}`;
  }
  function prettyPrint(xml) {
    const IND = "  ";
    const tokens = tokenise(xml);
    const lines = [];
    const origToFmt = /* @__PURE__ */ new Map();
    const fmtToOrig = /* @__PURE__ */ new Map();
    const fmtToPath = /* @__PURE__ */ new Map();
    const stack = [];
    function pushLine(text, origLine) {
      const fmtIdx = lines.length;
      if (!origToFmt.has(origLine)) origToFmt.set(origLine, fmtIdx);
      fmtToOrig.set(fmtIdx, origLine);
      lines.push(text);
    }
    function pathForChild(tag) {
      if (stack.length === 0) return `/${tag}`;
      const parent = stack[stack.length - 1];
      return `${parent.path}/${tag}[${parent.childCount}]`;
    }
    function allocateChild(tag) {
      const p = pathForChild(tag);
      if (stack.length > 0) stack[stack.length - 1].childCount++;
      return p;
    }
    let depth = 0;
    for (const tok of tokens) {
      const ind = IND.repeat(depth);
      switch (tok.type) {
        case "pi":
        case "doctype":
          pushLine(ind + tok.raw.trim(), tok.origLine);
          break;
        case "comment":
          pushLine(ind + tok.raw.trim(), tok.origLine);
          break;
        case "cdata": {
          pushLine(ind + tok.raw.trim(), tok.origLine);
          break;
        }
        case "open": {
          const elemPath = allocateChild(tok.tag);
          const firstFmtIdx = lines.length;
          pushLine(ind + formatTag(tok.tag, tok.attrs, false), tok.origLine);
          fmtToPath.set(firstFmtIdx, elemPath);
          stack.push({ path: elemPath, childCount: 0 });
          depth++;
          break;
        }
        case "self": {
          const elemPath = allocateChild(tok.tag);
          const firstFmtIdx = lines.length;
          pushLine(ind + formatTag(tok.tag, tok.attrs, true), tok.origLine);
          fmtToPath.set(firstFmtIdx, elemPath);
          break;
        }
        case "close": {
          depth = Math.max(0, depth - 1);
          stack.pop();
          const closeInd = IND.repeat(depth);
          if (lines.length > 0) {
            const prev = lines[lines.length - 1];
            if (new RegExp(`^\\s*<${tok.tag}(\\s[^>]*)?>$`).test(prev)) {
              lines[lines.length - 1] = prev + `</${tok.tag}>`;
              break;
            }
          }
          pushLine(closeInd + `</${tok.tag}>`, tok.origLine);
          break;
        }
        case "text": {
          const t = tok.raw.trim();
          if (!t) break;
          pushLine(ind + t, tok.origLine);
          break;
        }
      }
    }
    return { text: lines.join("\n"), origToFmt, fmtToOrig, fmtToPath };
  }
  function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function highlightLine(line) {
    const e = esc(line);
    if (/&lt;!\[CDATA\[/.test(e) || /\]\]&gt;/.test(e) || !/&lt;/.test(e) && !/&gt;/.test(e) && line.trim().length > 0 && line.trim().startsWith("https")) {
      return `<span class="cdata">${e}</span>`;
    }
    if (/&lt;!--/.test(e) || /--&gt;/.test(e)) return `<span class="comment">${e}</span>`;
    if (/&lt;!DOCTYPE/i.test(e)) return `<span class="comment">${e}</span>`;
    if (/^(\s*)&lt;\?/.test(e)) return `<span class="pi">${e}</span>`;
    if (/^(\s*)&lt;\//.test(e)) {
      return e.replace(/(&lt;\/)([\w:.-]+)(&gt;)/, '&lt;<span class="ct">/$2</span>&gt;');
    }
    if (/^(\s*)&lt;[\w]/.test(e)) {
      return e.replace(/^(\s*)(&lt;)([\w:.-]+)/, '$1&lt;<span class="t">$3</span>').replace(
        /([\w:.-]+)(=)(&quot;[^&]*&quot;)/g,
        '<span class="an">$1</span>$2<span class="av">$3</span>'
      ).replace(/(\/>|&gt;)$/, '<span class="t">$1</span>');
    }
    if (/^\s+[\w:.-]+=&quot;/.test(e)) {
      return e.replace(
        /([\w:.-]+)(=)(&quot;[^&]*&quot;)/g,
        '<span class="an">$1</span>$2<span class="av">$3</span>'
      );
    }
    if (line.length > 0 && !/^</.test(line.trim()) && /^\s/.test(line)) {
      return `<span class="cdata">${e}</span>`;
    }
    return e;
  }
  function injectXmlViewer(src) {
    const { text: formatted, origToFmt, fmtToOrig, fmtToPath } = prettyPrint(src);
    const lines = formatted.split("\n");
    const pad = String(lines.length).length;
    const pathToFmt = /* @__PURE__ */ new Map();
    for (const [fmtIdx, path] of fmtToPath) pathToFmt.set(path, fmtIdx);
    const iframe = document.createElementNS("http://www.w3.org/1999/xhtml", "iframe");
    iframe.style.cssText = "all:initial;position:fixed;inset:0;width:100vw;height:100vh;border:none;z-index:2147483640";
    (document.body ?? document.documentElement).appendChild(iframe);
    const iDoc = iframe.contentDocument;
    iDoc.open();
    iDoc.write(`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>VAST XML \u2014 vastlint</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{background:#0d0d17;color:#cdd6f4;height:100%;overflow:hidden}
#root{display:flex;flex-direction:column;height:100vh;
  font:13px/1.6 'JetBrains Mono','Fira Code','Cascadia Code','Consolas',monospace}
#toolbar{flex-shrink:0;display:flex;align-items:center;gap:8px;padding:5px 16px;
  background:#11111f;border-bottom:1px solid #1e1e35;
  font-family:system-ui,sans-serif;font-size:12px;color:#888}
.logo{color:#7ec8e3;font-weight:700;font-size:13px}
.url{opacity:.4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;flex:1}
#btn-native{margin-left:auto;flex-shrink:0;padding:3px 10px;border-radius:4px;border:1px solid #2e2e4e;
  background:#1a1a2e;color:#888;font-family:system-ui,sans-serif;font-size:11px;
  cursor:pointer;transition:border-color .15s,color .15s}
#btn-native:hover{border-color:#7ec8e3;color:#cdd6f4}
#scroll{flex:1;overflow:auto}
#wrap{display:flex;padding:12px 0}
#gutter{flex-shrink:0;padding:0 14px 0 16px;text-align:right;color:#2e2e4e;
  user-select:none;border-right:1px solid #1e1e35;white-space:pre;
  line-height:1.6;font-size:13px;display:flex;flex-direction:column}
.gln{display:block;line-height:1.6}
#code{flex:1;margin:0;padding:0 8px 0 0;white-space:pre;line-height:1.6;
  font-size:13px;background:transparent;tab-size:2}
.ln{display:block;white-space:pre}
.t  {color:#88b4e8}.ct {color:#88b4e8}.an {color:#c98de8}.av {color:#6abf69}
.comment{color:#5a6070;font-style:italic}.cdata{color:#5a7080}.pi{color:#e88}
</style></head><body>
<div id="root">
  <div id="toolbar">
    <span class="logo">vastlint</span>
    <span style="opacity:.3">&middot;</span>
    <span class="url" id="url-bar"></span>
    <button id="btn-native">&#x2715; Native view</button>
  </div>
  <div id="scroll"><div id="wrap">
    <div id="gutter"></div>
    <pre id="code"></pre>
  </div></div>
</div>
</body></html>`);
    iDoc.close();
    const iWin = iframe.contentWindow;
    const code = iDoc.getElementById("code");
    const gutter = iDoc.getElementById("gutter");
    const urlBar = iDoc.getElementById("url-bar");
    urlBar.textContent = iWin.location.href;
    iDoc.getElementById("btn-native").addEventListener("click", () => iframe.remove());
    for (let i = 0; i < lines.length; i++) {
      const gln = iDoc.createElement("span");
      gln.className = "gln";
      gln.textContent = String(i + 1).padStart(pad, " ");
      gutter.appendChild(gln);
      const ln = iDoc.createElement("span");
      ln.className = "ln";
      ln.dataset["ln"] = String(i);
      if (fmtToOrig.has(i)) ln.dataset["orig"] = String(fmtToOrig.get(i));
      if (fmtToPath.has(i)) ln.dataset["path"] = fmtToPath.get(i);
      const span = iDoc.createElement("span");
      span.innerHTML = highlightLine(lines[i]);
      ln.appendChild(span);
      code.appendChild(ln);
    }
    return { pre: code, origToFmt, pathToFmt };
  }

  // src/vastlint/detect.ts
  var VAST_SIGNATURE_RE = /(?:<\?xml[^>]*>[\s\S]{0,200})?<VAST[\s>\/]/i;

  // src/content/index.ts
  var MAX_VASTS = 10;
  var seen = /* @__PURE__ */ new Set();
  var lastResults = /* @__PURE__ */ new Map();
  var vastCounter = 0;
  var currentUrl = location.href;
  var siteDisabled = false;
  (async () => {
    try {
      const host = location.hostname;
      const stored = await chrome.storage.sync.get("disabledHosts");
      const disabled = stored.disabledHosts ?? [];
      if (disabled.includes(host)) {
        siteDisabled = true;
        return;
      }
      await Promise.resolve().then(() => (init_validator(), validator_exports));
      if (document.contentType === "text/xml" || document.contentType === "application/xml") {
        let src;
        try {
          const resp = await fetch(location.href);
          src = await resp.text();
        } catch {
          src = new XMLSerializer().serializeToString(document);
        }
        if (VAST_SIGNATURE_RE.test(src)) {
          const { pre: anchor, origToFmt, pathToFmt } = injectXmlViewer(src);
          const key = simpleHash(src);
          seen.add(key);
          lintAndRenderAll([{ xml: src, anchor, origToFmt, pathToFmt }]);
        }
        window.addEventListener("pagehide", clearAll);
        return;
      }
      scanDOM();
      observeMutations();
      hookNavigation();
    } catch (e) {
      console.error("[vastlint] failed to initialise", e);
    }
  })();
  function scanDOM() {
    if (siteDisabled) return;
    if (location.href !== currentUrl) {
      currentUrl = location.href;
      clearAll();
    }
    const candidates = collectCandidates(document.body);
    const toRelint = [];
    const toAdd = [];
    for (const c of candidates) {
      const existing = lastResults.get(c.anchor);
      const newHash = simpleHash(c.xml);
      if (existing) {
        if (existing.hash !== newHash) {
          seen.delete(existing.hash);
          seen.add(newHash);
          toRelint.push(c);
        }
      } else {
        if (seen.has(newHash)) continue;
        if (lastResults.size + toAdd.length >= MAX_VASTS) continue;
        seen.add(newHash);
        toAdd.push(c);
      }
    }
    const all = [...toRelint, ...toAdd];
    if (all.length === 0) return;
    lintAndRenderAll(all);
  }
  function observeMutations() {
    let structuralTimer = 0;
    let streamingTimer = 0;
    const STRUCTURAL_DELAY_MS = 200;
    const STREAMING_DELAY_MS = 800;
    const observer = new MutationObserver((mutations) => {
      let hasStructural = false;
      let hasStreaming = false;
      for (const m of mutations) {
        if (m.type === "childList" && m.addedNodes.length) hasStructural = true;
        if (m.type === "characterData") hasStreaming = true;
      }
      if (hasStructural) {
        clearTimeout(structuralTimer);
        structuralTimer = window.setTimeout(() => scanDOM(), STRUCTURAL_DELAY_MS);
      }
      if (hasStreaming) {
        clearTimeout(streamingTimer);
        streamingTimer = window.setTimeout(() => scanDOM(), STREAMING_DELAY_MS);
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }
  function clearAll() {
    currentUrl = location.href;
    for (const anchor of lastResults.keys()) {
      const el = anchor;
      el._vlCleanup?.();
    }
    document.querySelectorAll("[data-vastlint-overlay],[data-vastlint-panel]").forEach((el) => el.remove());
    seen.clear();
    lastResults.clear();
    try {
      chrome.runtime.sendMessage({ type: "UPDATE_BADGE", vasts: [] });
    } catch {
    }
  }
  function onNavigation() {
    clearAll();
    requestAnimationFrame(() => scanDOM());
  }
  function hookNavigation() {
    window.addEventListener("vastlint:nav", onNavigation);
    window.addEventListener("popstate", onNavigation);
    window.addEventListener("pagehide", clearAll);
  }
  function collectCandidates(root) {
    const results = [];
    const prelike = (root instanceof Element ? root : document).querySelectorAll(
      "pre, textarea, [data-vast], [data-ad-tag], [data-ad-tag-uri]"
    );
    for (const el of prelike) {
      const text = el.tagName === "TEXTAREA" ? el.value : el.textContent ?? "";
      if (VAST_SIGNATURE_RE.test(text)) {
        results.push({ xml: text.trim(), anchor: el });
      }
    }
    const scripts = (root instanceof Element ? root : document).querySelectorAll(
      'script[type="text/xml"], script[type="application/xml"]'
    );
    for (const el of scripts) {
      const text = el.textContent ?? "";
      if (VAST_SIGNATURE_RE.test(text)) {
        results.push({ xml: text.trim(), anchor: el });
      }
    }
    const walker = document.createTreeWalker(
      root instanceof Element ? root : document.body,
      NodeFilter.SHOW_TEXT,
      null
    );
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent ?? "";
      if (text.length > 100 && VAST_SIGNATURE_RE.test(text)) {
        const parent = node.parentElement;
        if (parent && !["PRE", "TEXTAREA", "SCRIPT", "STYLE"].includes(parent.tagName)) {
          results.push({ xml: text.trim(), anchor: parent });
        }
      }
    }
    return results;
  }
  async function lintAndRenderAll(candidates) {
    const results = await Promise.all(
      candidates.map(async ({ xml, anchor, origToFmt, pathToFmt }) => {
        const result = await validateVast(xml);
        renderPanel(result, anchor, origToFmt, pathToFmt);
        const adIdMatch = xml.match(/<Ad\b[^>]*\bid=["']([^"']+)["']/i);
        const existing = lastResults.get(anchor);
        const label = existing?.label ?? (adIdMatch ? adIdMatch[1] : `VAST #${++vastCounter}`);
        lastResults.set(anchor, { hash: simpleHash(xml), xml, result, label });
        return {
          label,
          version: result.version ?? null,
          errors: result.summary.errors,
          warnings: result.summary.warnings,
          infos: result.summary.infos ?? 0
        };
      })
    );
    try {
      chrome.runtime.sendMessage({ type: "UPDATE_BADGE", vasts: results });
    } catch {
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "DISABLE_SITE") {
      siteDisabled = true;
      clearAll();
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "ENABLE_SITE") {
      siteDisabled = false;
      scanDOM();
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "SCAN_NOW") {
      seen.clear();
      scanDOM();
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "FOCUS_VAST") {
      let found = false;
      for (const [anchor, entry] of lastResults) {
        if (entry.label === msg.label) {
          anchor.scrollIntoView({ behavior: "smooth", block: "center" });
          const el = anchor;
          const prev = el.style.outline;
          el.style.outline = "2px solid #63b3ed";
          el.style.outlineOffset = "4px";
          setTimeout(() => {
            el.style.outline = prev;
            el.style.outlineOffset = "";
          }, 1500);
          found = true;
          break;
        }
      }
      sendResponse({ ok: found });
      return true;
    }
    if (msg.type === "COPY_ANNOTATED_ONE") {
      let found;
      for (const entry of lastResults.values()) {
        if (entry.label === msg.label) {
          found = entry;
          break;
        }
      }
      if (!found) {
        sendResponse({ ok: false, reason: "VAST not found." });
        return true;
      }
      const text = buildAnnotatedXml(found.xml, found.result);
      sendResponse({ ok: true, text });
      return true;
    }
    if (msg.type !== "COPY_ANNOTATED") return;
    const parts = [];
    for (const { xml, result } of lastResults.values()) {
      parts.push(buildAnnotatedXml(xml, result));
    }
    if (parts.length === 0) {
      sendResponse({ ok: false, reason: "No VAST found on this page yet." });
      return;
    }
    sendResponse({ ok: true, count: parts.length, text: parts.join("\n\n<!-- \u2500\u2500\u2500 next VAST \u2500\u2500\u2500 -->\n\n") });
    return true;
  });
  function buildAnnotatedXml(xml, result) {
    const lineIssues = /* @__PURE__ */ new Map();
    for (const iss of result.issues) {
      const ln = iss.line ?? 1;
      if (!lineIssues.has(ln)) lineIssues.set(ln, []);
      lineIssues.get(ln).push(iss);
    }
    const lines = xml.split("\n");
    const out = [];
    const { errors, warnings, infos } = result.summary;
    out.push(`<!-- vastlint: ${errors} error(s), ${warnings} warning(s), ${infos} info(s) \u2014 VAST ${result.version ?? "?"} -->`);
    for (let i = 0; i < lines.length; i++) {
      const ln = i + 1;
      const issues = lineIssues.get(ln);
      if (issues) {
        for (const iss of issues) {
          const sev = iss.severity.toUpperCase().padEnd(7);
          const loc = iss.path ? ` @ ${iss.path}` : "";
          out.push(`<!-- vastlint ${sev} [${iss.id}]${loc}: ${iss.message} -->`);
        }
      }
      out.push(lines[i]);
    }
    return out.join("\n");
  }
  function simpleHash(s) {
    let h = 0;
    for (let i = 0; i < Math.min(s.length, 4096); i++) {
      h = Math.imul(31, h) + s.charCodeAt(i) | 0;
    }
    return String(h);
  }
})();
