"use strict";
(() => {
  // src/popup/popup.ts
  function escHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  async function init() {
    const status = document.getElementById("status");
    const statsEl = document.getElementById("stats");
    const errCount = document.getElementById("err-count");
    const warnCount = document.getElementById("warn-count");
    const infoCount = document.getElementById("info-count");
    const copyBtn = document.getElementById("copy-btn");
    const scanBtn = document.getElementById("scan-btn");
    const siteToggle = document.getElementById("site-toggle");
    const toggleLabel = siteToggle.querySelector(".toggle-label");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      status.textContent = "No active tab.";
      return;
    }
    const host = new URL(tab.url ?? "about:blank").hostname;
    const syncData = await chrome.storage.sync.get("disabledHosts");
    let disabledHosts = syncData.disabledHosts ?? [];
    let siteDisabled = disabledHosts.includes(host);
    function applyToggleState() {
      if (siteDisabled) {
        siteToggle.classList.remove("on");
        siteToggle.classList.add("disabled-state");
        toggleLabel.textContent = "off";
        siteToggle.title = `vastlint is OFF on ${host} \u2014 click to enable`;
      } else {
        siteToggle.classList.add("on");
        siteToggle.classList.remove("disabled-state");
        toggleLabel.textContent = "on";
        siteToggle.title = `vastlint is ON on ${host} \u2014 click to disable`;
      }
    }
    applyToggleState();
    siteToggle.addEventListener("click", async () => {
      siteDisabled = !siteDisabled;
      if (siteDisabled) {
        disabledHosts = [.../* @__PURE__ */ new Set([...disabledHosts, host])];
      } else {
        disabledHosts = disabledHosts.filter((h) => h !== host);
      }
      await chrome.storage.sync.set({ disabledHosts });
      applyToggleState();
      const msgType = siteDisabled ? "DISABLE_SITE" : "ENABLE_SITE";
      try {
        await chrome.tabs.sendMessage(tab.id, { type: msgType });
      } catch {
      }
      if (siteDisabled) {
        await chrome.storage.session.remove(`tab_${tab.id}`);
        await chrome.action.setBadgeText({ text: "", tabId: tab.id });
      }
      window.close();
    });
    const key = `tab_${tab.id}`;
    const stored = await chrome.storage.session.get(key);
    const data = stored[key];
    if (data) {
      status.style.display = "none";
      statsEl.style.display = "block";
      errCount.textContent = String(data.errors);
      warnCount.textContent = String(data.warnings);
      infoCount.textContent = String(data.infos ?? 0);
      copyBtn.style.display = "inline-flex";
      const statErr = document.getElementById("stat-err");
      const statWarn = document.getElementById("stat-warn");
      if (data.errors === 0) statErr.classList.add("zero");
      if (data.warnings === 0) statWarn.classList.add("zero");
      if (data.vasts && data.vasts.length > 1) {
        const breakdown = document.getElementById("breakdown");
        breakdown.style.display = "block";
        const list = document.getElementById("vast-list");
        list.innerHTML = data.vasts.map((v) => {
          const hasErr = v.errors > 0;
          const hasWarn = v.warnings > 0;
          const dot = hasErr ? "dot-err" : hasWarn ? "dot-warn" : "dot-ok";
          const pills = [
            v.errors > 0 ? `<span class="pill pill-err">${v.errors}E</span>` : "",
            v.warnings > 0 ? `<span class="pill pill-warn">${v.warnings}W</span>` : "",
            v.infos > 0 ? `<span class="pill pill-info">${v.infos}I</span>` : "",
            !hasErr && !hasWarn ? `<span class="pill pill-ok">\u2713</span>` : ""
          ].filter(Boolean).join("");
          const ver = v.version ? `<span class="vast-ver">VAST ${escHtml(v.version)}</span>` : "";
          return `<div class="vast-row" data-label="${escHtml(v.label)}">
          <span class="vast-dot ${dot}"></span>
          <span class="vast-label">${escHtml(v.label)}</span>
          ${ver}
          <span class="vast-pills">${pills}</span>
          <button class="focus-btn" data-label="${escHtml(v.label)}">focus</button>
          <button class="copy-one-btn" data-label="${escHtml(v.label)}" title="Copy annotated VAST">copy</button>
        </div>`;
        }).join("");
        list.querySelectorAll(".focus-btn").forEach((btn) => {
          btn.addEventListener("click", async () => {
            const label = btn.dataset.label;
            try {
              await chrome.tabs.sendMessage(tab.id, { type: "FOCUS_VAST", label });
            } catch {
            }
            window.close();
          });
        });
        list.querySelectorAll(".copy-one-btn").forEach((btn) => {
          btn.addEventListener("click", async () => {
            const label = btn.dataset.label;
            btn.disabled = true;
            btn.textContent = "\u2026";
            try {
              const response = await chrome.tabs.sendMessage(tab.id, { type: "COPY_ANNOTATED_ONE", label });
              if (response.ok && response.text) {
                await navigator.clipboard.writeText(response.text);
                btn.textContent = "\u2713";
                setTimeout(() => {
                  btn.disabled = false;
                  btn.textContent = "copy";
                }, 1500);
              } else {
                btn.textContent = "\u2715";
                setTimeout(() => {
                  btn.disabled = false;
                  btn.textContent = "copy";
                }, 1500);
              }
            } catch {
              btn.textContent = "\u2715";
              setTimeout(() => {
                btn.disabled = false;
                btn.textContent = "copy";
              }, 1500);
            }
          });
        });
      }
    } else {
      const url = tab.url ?? "";
      const isFileXml = url.startsWith("file://") && /\.xml(\?|#|$)/i.test(url);
      if (isFileXml) {
        status.innerHTML = `
        <strong>File access needed</strong>
        To validate local <code>.xml</code> files, enable
        <b>Allow access to file URLs</b> for this extension:<br><br>
        <code>chrome://extensions</code> \u2192 VAST lint \u2192 Details \u2192 toggle on
      `;
      }
    }
    copyBtn.addEventListener("click", async () => {
      copyBtn.disabled = true;
      copyBtn.textContent = "Copying\u2026";
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type: "COPY_ANNOTATED" });
        if (response.ok && response.text) {
          await navigator.clipboard.writeText(response.text);
          copyBtn.textContent = `\u2713 Copied${response.count && response.count > 1 ? ` (${response.count})` : ""}`;
          copyBtn.classList.add("success");
        } else {
          copyBtn.textContent = `\u2715 ${response.reason ?? "Failed"}`;
          copyBtn.classList.add("error");
        }
      } catch {
        copyBtn.textContent = "\u2715 Could not reach page";
        copyBtn.classList.add("error");
      }
      setTimeout(() => {
        copyBtn.disabled = false;
        copyBtn.textContent = "\u{1F4CB} Copy VAST";
        copyBtn.classList.remove("success", "error");
      }, 2500);
    });
    scanBtn.addEventListener("click", async () => {
      scanBtn.disabled = true;
      scanBtn.textContent = "\u27F3 Scanning\u2026";
      try {
        await chrome.tabs.sendMessage(tab.id, { type: "SCAN_NOW" });
        setTimeout(() => window.close(), 600);
      } catch {
        scanBtn.textContent = "\u2715 Failed";
        setTimeout(() => {
          scanBtn.disabled = false;
          scanBtn.textContent = "\u27F3 Scan page";
        }, 1500);
      }
    });
    initPasteAnalyzer();
  }
  function initPasteAnalyzer() {
    const textarea = document.getElementById("paste-input");
    const clearBtn = document.getElementById("paste-clear");
    const openBtn = document.getElementById("paste-open");
    const pasteSection = document.getElementById("paste-section");
    function updateBtn() {
      const has = textarea.value.trim().length > 0;
      textarea.classList.toggle("has-content", has);
      clearBtn.style.display = has ? "inline" : "none";
      openBtn.disabled = !has;
    }
    textarea.addEventListener("input", updateBtn);
    textarea.addEventListener("paste", () => {
      setTimeout(async () => {
        const xml = textarea.value.trim();
        if (!xml) return;
        try {
          await chrome.storage.session.set({ paste_xml: xml });
          pasteSection.classList.add("analyzing");
          await new Promise((r) => setTimeout(r, 700));
          await chrome.tabs.create({ url: chrome.runtime.getURL("analysis.html") });
          window.close();
        } catch {
          pasteSection.classList.remove("analyzing");
          updateBtn();
        }
      }, 0);
    });
    clearBtn.addEventListener("click", () => {
      textarea.value = "";
      updateBtn();
    });
    openBtn.addEventListener("click", async () => {
      const xml = textarea.value.trim();
      if (!xml) return;
      openBtn.disabled = true;
      openBtn.textContent = "Opening\u2026";
      try {
        await chrome.storage.session.set({ paste_xml: xml });
        await chrome.tabs.create({ url: chrome.runtime.getURL("analysis.html") });
        window.close();
      } catch (e) {
        openBtn.disabled = false;
        openBtn.textContent = "\u2197 Analyze in new tab";
      }
    });
  }
  init().catch(console.error);
})();
