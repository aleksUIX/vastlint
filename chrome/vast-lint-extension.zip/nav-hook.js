"use strict";
(() => {
  // src/nav-hook/nav-hook.ts
  (function() {
    const dispatch = () => window.dispatchEvent(new CustomEvent("vastlint:nav"));
    const orig = {
      push: history.pushState.bind(history),
      replace: history.replaceState.bind(history)
    };
    history.pushState = function(...args) {
      orig.push(...args);
      dispatch();
    };
    history.replaceState = function(...args) {
      orig.replace(...args);
      dispatch();
    };
    window.addEventListener("popstate", dispatch);
  })();
})();
